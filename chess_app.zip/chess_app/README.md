
# 🧠 Chess App - Çevrimiçi Satranç Uygulaması

Chess App, kullanıcıların gerçek zamanlı olarak birbirlerine karşı çevrimiçi satranç oynamalarını sağlayan web tabanlı bir platformdur. Proje, modern web teknolojileri kullanılarak geliştirilmiş olup hem istemci (frontend) hem de sunucu (backend) bileşenlerini içerir.

## 🚀 Özellikler

- Gerçek zamanlı oyuncu eşleştirme
- Canlı hamle aktarımı ve senkronize tahta yönetimi
- Oyuncu süre yönetimi
- Oyun geçmişi takibi
- Bilgisayara karşı oynama (yapay zeka opsiyonu entegre edilebilir)
- MongoDB ile kullanıcı ve oyun verisi saklama

## 🧱 Proje Mimarisi

### 🔧 Backend (Node.js + Express)

- REST API ve Socket.IO ile gerçek zamanlı iletişim
- MongoDB veritabanı bağlantısı (`db.js`)
- Oyuncu ve oyun verisi için modeller (`models/`)
- Oyun yönetimi (`controllers/chessController.js`)
- Hamle doğrulama ve oyun kuralları (`chess.js`)
- Yardımcı fonksiyonlar (`utils/`)

### 🎨 Frontend (public dizini)

- Modern JavaScript ile oyun arayüzü
- WebSocket üzerinden canlı oyun durumu alma ve gönderme
- Tahta ve hamle animasyonları
- Oyun başlatma, bekleme odası ve süre yönetimi

## 📁 Klasör Yapısı

```
chess_app/
│
├── backend/
│   ├── controllers/
│   ├── models/
│   ├── routes/
│   ├── utils/
│   ├── chess.js
│   ├── server.js
│   └── db.js
│
├── public/              # İstemci arayüzü
├── package.json         # Ana bağımlılıklar
└── README.md
```

## 🔨 Kurulum Talimatları

### Gereksinimler

- Node.js (v18+)
- MongoDB (lokal veya Atlas)

### Adımlar

```bash
# Ana klasöre gir
cd chess_app

# Gerekli modülleri yükle
npm install

# Backend klasörüne gir ve modülleri yükle
cd backend
npm install

# MongoDB bağlantısını yapılandır (db.js içinde)
# Uygulamayı başlat

cd chess_app
mongod

cd chess_app public 
python -m http.server

cd chess_app backend 
node server.js
```

## 📡 Gerçek Zamanlı Oyun Akışı

Uygulama, `socket.io` üzerinden kullanıcı bağlantılarını takip eder ve hamleleri senkronize eder. Bağlantılar ve hamle olayları sunucuda loglanır.

## 📌 Notlar

- Projede `chess.js` dosyasında oyun motoru yönetilmektedir. Tahta yapısı, hamle geçerliliği, şah çekme ve mat olma gibi durumlar burada kontrol edilir.
- Geliştirme sürecinde `MongoDB Atlas`, `Postman`, `VS Code` ve `socket.io-client` kullanılmıştır.


# ENGLISH 

Chess App is a web-based platform that enables users to play real-time online chess against each other. The project is built using modern web technologies and includes both client-side (frontend) and server-side (backend) components.

🚀 Features
Real-time player matchmaking

Live move synchronization and board state management

Player time control

Game history tracking

Play against computer (AI support can be integrated)

User and game data storage with MongoDB

🧱 Project Architecture
🔧 Backend (Node.js + Express)
Real-time communication with REST API and Socket.IO

MongoDB database integration (db.js)

Models for users and games (models/)

Game logic management (controllers/chessController.js)

Move validation and chess rules (chess.js)

Utility functions (utils/)

🎨 Frontend (public directory)
Game interface using modern JavaScript

Real-time game state updates via WebSocket

Board rendering and move animations

Game start, waiting room, and timer control

📁 Project Structure
csharp
Copy
Edit
chess_app/
│
├── backend/
│   ├── controllers/
│   ├── models/
│   ├── routes/
│   ├── utils/
│   ├── chess.js
│   ├── server.js
│   └── db.js
│
├── public/              # Client interface
├── package.json         # Main dependencies
└── README.md
🔨 Installation Guide
Requirements
Node.js (v18+)

MongoDB (local or Atlas)

Steps
bash
Copy
Edit
# Go to the main directory
cd chess_app

# Install dependencies
npm install

# Navigate to the backend and install dependencies
cd backend
npm install

# Configure the MongoDB connection (inside db.js)
# Start the application

cd chess_app
mongod

cd chess_app/public 
python -m http.server

cd chess_app/backend 
node server.js
📡 Real-Time Game Flow
The application uses socket.io to track user connections and synchronize moves in real-time. Connections and game events are logged on the server.

📌 Notes
The game engine is managed in chess.js. It handles board state, move validation, check and checkmate detection.

During development, tools like MongoDB Atlas, Postman, VS Code, and socket.io-client were used.