// Bilgisayara karşı satranç oyunu için JavaScript
const boardElement = document.getElementById("board");
const token = localStorage.getItem("token");
const username = localStorage.getItem("username");

// Token kontrolü
if (!token || !username) {
  alert("Giriş yapmalısınız.");
  window.location.href = "login.html";
}

document.getElementById("white-player-name").innerText = username;

const API_URL = "http://localhost:5000/api";
let gameId = null;
let playerColor = "white"; // Varsayılan renk
let difficulty = "medium"; // Varsayılan zorluk

const game = new Chess();
let board = null;

// Timer değişkenleri
let whiteTime = 600; // 10 dakika (saniye cinsinden)
let blackTime = 600;
let activeTimer = null;
let timerInterval = null;
let gameStarted = false;
let gameEnded = false;
let moveNumber = 1; // Hamle numarası
let firstMoveMade = false; // İlk hamle yapıldı mı?

// Timer elementleri
const whiteTimerElement = document.getElementById("white-time");
const blackTimerElement = document.getElementById("black-time");
const whiteTimerContainer = document.getElementById("white-timer");
const blackTimerContainer = document.getElementById("black-timer");
const startTimerButton = document.getElementById("start-timer");
const resetTimerButton = document.getElementById("reset-timer");
const resignButton = document.getElementById("resign-game");
const timeSelect = document.getElementById("time-select");
const movesListElement = document.getElementById("moves-list");
const statusElement = document.getElementById("status");

// Pencere boyutu değiştiğinde tahtayı yeniden boyutlandır
window.addEventListener('resize', function() {
  if (board) {
    board.resize();
  }
});

// Timer başlatma butonu
startTimerButton.addEventListener("click", () => {
  if (!gameStarted) {
    gameStarted = true;
    startTimerButton.disabled = true;
    resetTimerButton.disabled = true;
    timeSelect.disabled = true;
    startTimer("w"); // Beyaz başlar
  }
});

// Timer sıfırlama butonu
resetTimerButton.addEventListener("click", () => {
  resetTimers();
  resetMovesList();
});

// Terk et butonu
resignButton.addEventListener("click", () => {
  if (gameStarted && !gameEnded) {
    resignGame();
  }
});

// Süre seçimi değiştiğinde
timeSelect.addEventListener("change", () => {
  const selectedTime = parseInt(timeSelect.value);
  whiteTime = selectedTime;
  blackTime = selectedTime;
  updateTimerDisplay();
});

// Timer'ı başlat
function startTimer(color) {
  stopTimer(); // Önceki timer'ı durdur
  
  activeTimer = color;
  
  // Aktif timer'ı vurgula
  whiteTimerContainer.classList.remove("active");
  blackTimerContainer.classList.remove("active");
  
  if (color === "w") {
    whiteTimerContainer.classList.add("active");
  } else {
    blackTimerContainer.classList.add("active");
  }
  
  timerInterval = setInterval(() => {
    if (activeTimer === "w") {
      whiteTime--;
      if (whiteTime <= 30) { // Son 30 saniye
        whiteTimerContainer.classList.add("danger");
      }
      if (whiteTime <= 0) {
        timeOut("w");
      }
    } else {
      blackTime--;
      if (blackTime <= 30) { // Son 30 saniye
        blackTimerContainer.classList.add("danger");
      }
      if (blackTime <= 0) {
        timeOut("b");
      }
    }
    updateTimerDisplay();
  }, 1000);
}

// Timer'ı durdur
function stopTimer() {
  clearInterval(timerInterval);
  timerInterval = null;
}

// Süre bittiğinde
function timeOut(color) {
  stopTimer();
  gameEnded = true;
  
  if (color === "w") {
    alert("Süreniz bitti! Siyah (Bilgisayar) kazandı.");
    statusElement.innerText = "Süre bitti! Siyah kazandı.";
    finishGame("0-1", "timeout");
  } else {
    alert("Bilgisayarın süresi bitti! Beyaz kazandı.");
    statusElement.innerText = "Süre bitti! Beyaz kazandı.";
    finishGame("1-0", "timeout");
  }
}

// Timer göstergesini güncelle
function updateTimerDisplay() {
  whiteTimerElement.innerText = formatTime(whiteTime);
  blackTimerElement.innerText = formatTime(blackTime);
}

// Süreyi formatla (mm:ss)
function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
}

// Timer'ları sıfırla
function resetTimers() {
  stopTimer();
  gameStarted = false;
  gameEnded = false;
  firstMoveMade = false;
  
  const selectedTime = parseInt(timeSelect.value);
  whiteTime = selectedTime;
  blackTime = selectedTime;
  
  whiteTimerContainer.classList.remove("active", "danger");
  blackTimerContainer.classList.remove("active", "danger");
  
  startTimerButton.disabled = false;
  resetTimerButton.disabled = false;
  timeSelect.disabled = false;
  
  updateTimerDisplay();
}

// Hamle listesini sıfırla
function resetMovesList() {
  movesListElement.innerHTML = "";
  moveNumber = 1;
}

// Hamle listesine hamle ekle
function addMoveToList(move, color) {
  // Hamle SAN notasyonunu al
  const san = move.san;
  
  // Eğer beyaz hamle ise yeni satır oluştur
  if (color === 'w') {
    const row = document.createElement('tr');
    row.id = `move-${moveNumber}`;
    row.innerHTML = `
      <td>${moveNumber}.</td>
      <td>${san}</td>
      <td></td>
    `;
    movesListElement.appendChild(row);
  } 
  // Eğer siyah hamle ise mevcut satırı güncelle
  else {
    const row = document.getElementById(`move-${moveNumber}`);
    if (row) {
      const cells = row.getElementsByTagName('td');
      if (cells.length > 2) {
        cells[2].textContent = san;
      }
      moveNumber++;
    }
  }
  
  // Hamle listesini en alta kaydır
  const moveList = document.querySelector('.move-list');
  moveList.scrollTop = moveList.scrollHeight;
}

async function startGame() {
  try {
    difficulty = document.getElementById("difficulty-select").value || "medium";
    const timeControl = parseInt(timeSelect.value);
    
    const res = await fetch(`${API_URL}/computer`, {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify({ 
        username, 
        difficulty,
        timeControl,
        userElo: localStorage.getItem("userElo") || 1200
      })
    });
    
    if (!res.ok) {
      throw new Error("Bilgisayar oyunu başlatılamadı");
    }
    
    const data = await res.json();
    gameId = data._id;
    console.log("Oyun ID:", gameId);
    
    // Bilgisayar adını göster
    document.getElementById("black-player-name").innerText = `Bilgisayar (${difficulty.charAt(0).toUpperCase() + difficulty.slice(1)})`;
    
    // Başlangıçta timer'ları ayarla
    resetTimers();
    
    // Hamle listesini sıfırla
    resetMovesList();
    
    // Oyun durumunu güncelle
    updateStatus();
    
    // Oyun bölümünü göster
    document.getElementById("lobby-section").style.display = "none";
    document.getElementById("game-section").style.display = "block";
    
    // Tahtayı başlangıç pozisyonuna getir
    game.reset();
    board.position('start');
    
    return true;
  } catch (err) {
    console.error("Oyun başlatma hatası:", err);
    alert("Oyun başlatılamadı: " + err.message);
    return false;
  }
}

function onDragStart(source, piece) {
  // Oyun bittiyse hamle yapılamaz
  if (game.game_over() || gameEnded) return false;
  
  // Sıra kimde kontrolü
  if (game.turn() === 'w' && piece.search(/^b/) !== -1) return false;
  if (game.turn() === 'b' && piece.search(/^w/) !== -1) return false;
  
  // Bilgisayara karşı oyunda, sadece beyaz taşları hareket ettirebiliriz
  if (game.turn() === 'b') return false;
}

function onDrop(source, target) {
  const move = game.move({ from: source, to: target, promotion: 'q' });
  if (move === null) return 'snapback';

  // İlk hamle yapıldıysa ve timer başlamadıysa, timer'ı başlat
  if (!firstMoveMade && !gameStarted) {
    firstMoveMade = true;
    gameStarted = true;
    startTimerButton.disabled = true;
    resetTimerButton.disabled = true;
    timeSelect.disabled = true;
    startTimer('w');
  }

  // Hamleyi listeye ekle
  addMoveToList(move, 'w');

  // Hamle yapıldı, timer'ı değiştir
  if (gameStarted && !gameEnded) {
    startTimer('b');
  }

  updateStatus();
  board.position(game.fen());

  // Bilgisayar hamlesi yap
  if (game.turn() === 'b' && !game.game_over() && !gameEnded) {
    setTimeout(makeComputerMove, 500);
  }
}

async function makeComputerMove() {
  try {
    const res = await fetch(`${API_URL}/computer/move/${gameId}`, {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify({ 
        fen: game.fen(),
        difficulty
      })
    });
    
    if (!res.ok) {
      throw new Error("Bilgisayar hamlesi yapılamadı");
    }
    
    const data = await res.json();
    
    if (data.move) {
      const move = game.move({
        from: data.move.from,
        to: data.move.to,
        promotion: data.move.promotion || 'q'
      });
      
      // Bilgisayar hamlesini listeye ekle
      addMoveToList(move, 'b');
      
      board.position(game.fen());
      updateStatus();
      
      // Bilgisayar hamle yaptı, timer'ı değiştir
      if (gameStarted && !gameEnded) {
        startTimer('w');
      }
    }
  } catch (err) {
    console.error("Bilgisayar hamlesi hatası:", err);
    alert("Bilgisayar hamlesi yapılamadı: " + err.message);
  }
}

function updateStatus() {
  let status = '';
  const moveColor = game.turn() === 'w' ? 'Beyaz' : 'Siyah';

  if (game.in_checkmate()) {
    status = `Mat! ${moveColor === 'Beyaz' ? 'Siyah' : 'Beyaz'} kazandı.`;
    gameEnded = true;
    stopTimer();
    
    // Oyun sonucunu kaydet
    const result = moveColor === 'Beyaz' ? "0-1" : "1-0";
    finishGame(result, "checkmate");
  } else if (game.in_draw()) {
    status = "Beraberlik.";
    gameEnded = true;
    stopTimer();
    
    // Beraberlik sonucunu kaydet
    finishGame("1/2-1/2", "draw");
  } else {
    status = `${moveColor}'ın sırası.`;
    if (game.in_check()) {
      status += " Şah var!";
    }
  }
  
  statusElement.innerText = status;
  
  // Oyun başladıysa, süre butonlarını kaldır ve sadece terk et butonunu göster
  if (gameStarted) {
    startTimerButton.style.display = "none";
    resetTimerButton.style.display = "none";
    resignButton.style.display = "inline-block";
  }
}

function resignGame() {
  if (confirm("Oyunu terk etmek istediğinize emin misiniz?")) {
    gameEnded = true;
    stopTimer();
    
    // Terk etme sonucunu kaydet
    finishGame("0-1", "resignation");
    
    statusElement.innerText = "Oyunu terk ettiniz. Bilgisayar kazandı.";
    alert("Oyunu terk ettiniz. Bilgisayar kazandı.");
  }
}

async function finishGame(result = null, reason = null) {
  if (!gameId) return;
  
  // Timer'ı durdur
  stopTimer();
  gameEnded = true;
  
  try {
    const res = await fetch(`${API_URL}/games/finish/${gameId}`, {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify({ 
        result: result || "1/2-1/2",
        reason: reason || "normal"
      })
    });
    
    if (!res.ok) {
      throw new Error("Oyun sonucu kaydedilemedi");
    }
    
    console.log("Oyun sonucu kaydedildi:", result, reason);
    
    // ELO değişimini göster (bilgisayara karşı oyunda ELO değişimi olmayabilir)
    const data = await res.json();
    if (data.eloChange) {
      const eloChangeText = data.eloChange > 0 ? `+${data.eloChange}` : data.eloChange;
      alert(`Oyun sonucu: ${result}\nELO değişimi: ${eloChangeText}`);
    }
  } catch (err) {
    console.error("Oyun sonucu kaydetme hatası:", err);
  }
}

// Chessboard başlat
board = Chessboard('board', {
  draggable: true,
  position: 'start',
  pieceTheme: 'img/chesspieces/wikipedia/{piece}.png',
  onDragStart,
  onDrop,
  onSnapEnd: () => board.position(game.fen())
});

// Sayfa yüklendiğinde
window.addEventListener("load", function() {
  // Token kontrolü tekrar yap
  if (!token || !username) {
    alert("Giriş yapmalısınız.");
    window.location.href = "login.html";
    return;
  }
  
  // Başlangıçta timer'ları ayarla
  const selectedTime = parseInt(timeSelect.value);
  whiteTime = selectedTime;
  blackTime = selectedTime;
  updateTimerDisplay();
  
  // Oyun durumunu güncelle
  updateStatus();
});

// Bilgisayara karşı oyna butonunu ayarla
document.getElementById("computer-game").addEventListener("click", startGame);

// Lobiye dön butonu
function backToLobby() {
  if (gameStarted && !gameEnded) {
    if (confirm("Devam eden oyunu terk etmek istediğinize emin misiniz?")) {
      resignGame();
    } else {
      return;
    }
  }
  
  document.getElementById("game-section").style.display = "none";
  document.getElementById("lobby-section").style.display = "block";
}

// Çıkış yap
function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("username");
  window.location.href = "login.html";
}
