// Multiplayer satranç oyunu için JavaScript
const boardElement = document.getElementById("board");
const username = localStorage.getItem("username");
document.getElementById("white-player-name").innerText = username;

const API_URL = "http://localhost:5000/api";
const socket = io("http://localhost:5000");
let gameId = null;
let playerColor = "white"; // Varsayılan renk
let opponentName = "";

const game = new Chess();
let board = null;

// Timer değişkenleri
let whiteTime = 600; // 10 dakika (saniye cinsinden)
let blackTime = 600;
let activeTimer = null;
let timerInterval = null;
let gameStarted = false;
let gameEnded = false;
let moveNumber = 1; // Hamle numarası

// Timer elementleri
const whiteTimerElement = document.getElementById("white-time");
const blackTimerElement = document.getElementById("black-time");
const whiteTimerContainer = document.getElementById("white-timer");
const blackTimerContainer = document.getElementById("black-timer");
const timeSelect = document.getElementById("time-select");
const movesListElement = document.getElementById("moves-list");
const statusElement = document.getElementById("status");
const waitingOverlay = document.getElementById("waiting-overlay");
const opponentNameElement = document.getElementById("black-player-name");

// Pencere boyutu değiştiğinde tahtayı yeniden boyutlandır
window.addEventListener('resize', function() {
  if (board) {
    board.resize();
  }
});

// Socket.IO bağlantısı
socket.on("connect", () => {
  console.log("Socket.IO bağlantısı kuruldu");
  
  // Kullanıcı bağlantısını bildir
  socket.emit("user_connected", username);
});

// Eşleşme arama
function findMatch() {
  const timeControl = parseInt(timeSelect.value);
  
  // Eşleşme aramayı başlat
  socket.emit("find_match", {
    username,
    timeControl
  });
  
  // Bekleme ekranını göster
  waitingOverlay.style.display = "flex";
  statusElement.innerText = "Rakip bekleniyor...";
}

// Eşleşme bekleme
socket.on("waiting_for_match", () => {
  console.log("Eşleşme bekleniyor...");
  statusElement.innerText = "Rakip bekleniyor...";
});

// Eşleşme bulundu
socket.on("match_found", (data) => {
  console.log("Eşleşme bulundu:", data);
  
  // Oyun bilgilerini kaydet
  gameId = data.gameId;
  opponentName = data.opponent;
  playerColor = data.color;
  
  // Bekleme ekranını kaldır
  waitingOverlay.style.display = "none";
  
  // Rakip adını göster
  if (playerColor === "white") {
    document.getElementById("white-player-name").innerText = username;
    document.getElementById("black-player-name").innerText = opponentName;
  } else {
    document.getElementById("white-player-name").innerText = opponentName;
    document.getElementById("black-player-name").innerText = username;
  }
  
  // Tahtayı doğru yönde göster
  board.orientation(playerColor);
  
  // Oyunu başlat
  resetGame();
  gameStarted = true;
  
  // Beyaz başlar
  if (playerColor === "white") {
    startTimer("w");
    statusElement.innerText = "Sizin sıranız (Beyaz)";
  } else {
    startTimer("w"); // Yine beyaz başlar ama bu sefer rakip
    statusElement.innerText = "Rakibin sırası (Beyaz)";
  }
});

// Eşleşme hatası
socket.on("match_error", (data) => {
  console.error("Eşleşme hatası:", data.message);
  waitingOverlay.style.display = "none";
  alert("Eşleşme hatası: " + data.message);
});

// Rakip hamle yaptığında
socket.on("opponent_move", (data) => {
  console.log("Rakip hamle yaptı:", data);
  
  // Hamleyi yap
  const move = game.move({
    from: data.move.from,
    to: data.move.to,
    promotion: data.move.promotion || 'q'
  });
  
  if (move) {
    // Tahtayı güncelle
    board.position(game.fen());
    
    // Hamleyi listeye ekle
    const moveColor = playerColor === "white" ? "b" : "w";
    addMoveToList(move, moveColor);
    
    // Sıra değişti, timer'ı güncelle
    const newTurn = game.turn();
    startTimer(newTurn);
    
    // Durum kontrolü
    checkGameStatus();
  }
});

// Broadcast ile gelen hamleleri de dinle (yedek mekanizma)
socket.on("opponent_move_broadcast", (data) => {
  console.log("Broadcast ile hamle alındı:", data);
  
  // Bu hamle bize mi gönderilmiş kontrol et
  if (data.targetUsername === username) {
    console.log("Bu hamle bize gönderilmiş, işleniyor...");
    
    // Hamleyi yap
    const move = game.move({
      from: data.move.from,
      to: data.move.to,
      promotion: data.move.promotion || 'q'
    });
    
    if (move) {
      // Tahtayı güncelle
      board.position(game.fen());
      
      // Hamleyi listeye ekle
      const moveColor = playerColor === "white" ? "b" : "w";
      addMoveToList(move, moveColor);
      
      // Sıra değişti, timer'ı güncelle
      const newTurn = game.turn();
      startTimer(newTurn);
      
      // Durum kontrolü
      checkGameStatus();
    }
  }
});

// Oyun sona erdiğinde
socket.on("game_over", (data) => {
  console.log("Oyun bitti:", data);
  
  gameEnded = true;
  stopTimer();
  
  let resultMessage = "";
  
  if (data.reason === "checkmate") {
    if ((data.result === "1-0" && playerColor === "white") || 
        (data.result === "0-1" && playerColor === "black")) {
      resultMessage = "Tebrikler! Şah mat yaparak kazandınız.";
    } else {
      resultMessage = "Şah mat oldunuz. Rakibiniz kazandı.";
    }
  } else if (data.reason === "timeout") {
    if ((data.result === "1-0" && playerColor === "white") || 
        (data.result === "0-1" && playerColor === "black")) {
      resultMessage = "Rakibinizin süresi bitti. Kazandınız!";
    } else {
      resultMessage = "Süreniz bitti. Rakibiniz kazandı.";
    }
  } else if (data.reason === "resignation") {
    if ((data.result === "1-0" && playerColor === "white") || 
        (data.result === "0-1" && playerColor === "black")) {
      resultMessage = "Rakibiniz terk etti. Kazandınız!";
    } else {
      resultMessage = "Oyunu terk ettiniz. Rakibiniz kazandı.";
    }
  } else if (data.result === "1/2-1/2") {
    resultMessage = "Oyun berabere bitti.";
  }
  
  // ELO değişimini göster
  if (data.eloChange) {
    const eloChangeText = data.eloChange > 0 ? `+${data.eloChange}` : data.eloChange;
    resultMessage += ` ELO değişimi: ${eloChangeText}`;
  }
  
  statusElement.innerText = resultMessage;
  alert(resultMessage);
});

// Timer'ı başlat
function startTimer(color) {
  stopTimer(); // Önceki timer'ı durdur
  
  activeTimer = color;
  
  // Aktif timer'ı vurgula
  whiteTimerContainer.classList.remove("active");
  blackTimerContainer.classList.remove("active");
  
  if (color === "w") {
    whiteTimerContainer.classList.add("active");
    
    // Sıra kontrolü
    if (playerColor === "white") {
      statusElement.innerText = "Sizin sıranız (Beyaz)";
    } else {
      statusElement.innerText = "Rakibin sırası (Beyaz)";
    }
  } else {
    blackTimerContainer.classList.add("active");
    
    // Sıra kontrolü
    if (playerColor === "black") {
      statusElement.innerText = "Sizin sıranız (Siyah)";
    } else {
      statusElement.innerText = "Rakibin sırası (Siyah)";
    }
  }
  
  timerInterval = setInterval(() => {
    if (activeTimer === "w") {
      whiteTime--;
      if (whiteTime <= 30) { // Son 30 saniye
        whiteTimerContainer.classList.add("danger");
      }
      if (whiteTime <= 0) {
        timeOut("w");
      }
    } else {
      blackTime--;
      if (blackTime <= 30) { // Son 30 saniye
        blackTimerContainer.classList.add("danger");
      }
      if (blackTime <= 0) {
        timeOut("b");
      }
    }
    updateTimerDisplay();
  }, 1000);
}

// Timer'ı durdur
function stopTimer() {
  clearInterval(timerInterval);
  timerInterval = null;
}

// Süre bittiğinde
function timeOut(color) {
  stopTimer();
  gameEnded = true;
  
  // Oyun sonucunu bildir
  if (gameId) {
    const result = color === "w" ? "0-1" : "1-0"; // Beyaz süre bittiyse siyah kazanır, tersi de geçerli
    socket.emit("game_over", {
      gameId,
      result,
      reason: "timeout"
    });
  }
  
  if (color === "w") {
    statusElement.innerText = "Beyazın süresi bitti! Siyah kazandı.";
  } else {
    statusElement.innerText = "Siyahın süresi bitti! Beyaz kazandı.";
  }
}

// Timer göstergesini güncelle
function updateTimerDisplay() {
  whiteTimerElement.innerText = formatTime(whiteTime);
  blackTimerElement.innerText = formatTime(blackTime);
}

// Süreyi formatla (mm:ss)
function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
}

// Oyunu sıfırla
function resetGame() {
  game.reset();
  board.position('start');
  
  // Timer'ları sıfırla
  stopTimer();
  gameEnded = false;
  
  const selectedTime = parseInt(timeSelect.value);
  whiteTime = selectedTime;
  blackTime = selectedTime;
  
  whiteTimerContainer.classList.remove("active", "danger");
  blackTimerContainer.classList.remove("active", "danger");
  
  updateTimerDisplay();
  
  // Hamle listesini sıfırla
  resetMovesList();
}

// Hamle listesini sıfırla
function resetMovesList() {
  movesListElement.innerHTML = "";
  moveNumber = 1;
}

// Hamle listesine hamle ekle
function addMoveToList(move, color) {
  // Hamle SAN notasyonunu al
  const san = move.san;
  
  // Eğer beyaz hamle ise yeni satır oluştur
  if (color === 'w') {
    const row = document.createElement('tr');
    row.id = `move-${moveNumber}`;
    row.innerHTML = `
      <td>${moveNumber}.</td>
      <td>${san}</td>
      <td></td>
    `;
    movesListElement.appendChild(row);
  } 
  // Eğer siyah hamle ise mevcut satırı güncelle
  else {
    const row = document.getElementById(`move-${moveNumber}`);
    if (row) {
      const cells = row.getElementsByTagName('td');
      if (cells.length > 2) {
        cells[2].textContent = san;
      }
      moveNumber++;
    }
  }
  
  // Hamle listesini en alta kaydır
  const moveList = document.querySelector('.move-list');
  moveList.scrollTop = moveList.scrollHeight;
}

function onDragStart(source, piece) {
  // Oyun bittiyse hamle yapılamaz
  if (game.game_over() || gameEnded) return false;
  
  // Sıra kontrolü
  const turn = game.turn();
  
  // Eğer oyuncunun rengi beyaz ve sıra beyazda değilse veya
  // oyuncunun rengi siyah ve sıra siyahta değilse hamle yapılamaz
  if ((playerColor === "white" && turn === 'b') || 
      (playerColor === "black" && turn === 'w')) {
    return false;
  }
  
  // Doğru renkteki taşları hareket ettir
  if (turn === 'w' && piece.search(/^b/) !== -1) return false;
  if (turn === 'b' && piece.search(/^w/) !== -1) return false;
}

function onDrop(source, target) {
  // Hamleyi yap
  const move = game.move({ 
    from: source, 
    to: target, 
    promotion: 'q' // Şimdilik otomatik vezir terfi
  });
  
  // Geçersiz hamle
  if (move === null) return 'snapback';

  // Hamleyi listeye ekle
  const moveColor = playerColor === "white" ? "w" : "b";
  addMoveToList(move, moveColor);

  // Hamleyi socket üzerinden gönder
  socket.emit("make_move", {
    gameId,
    move: {
      from: source,
      to: target,
      promotion: move.promotion
    },
    fen: game.fen(),
    remainingTime: playerColor === "white" ? whiteTime : blackTime
  });
  
  // Sıra değişti, timer'ı güncelle
  const newTurn = game.turn();
  startTimer(newTurn);
  
  // Durum kontrolü
  checkGameStatus();
}

// Oyun durumunu kontrol et
function checkGameStatus() {
  // Şah mat kontrolü
  if (game.in_checkmate()) {
    const winner = game.turn() === 'w' ? 'b' : 'w';
    const result = winner === 'w' ? "1-0" : "0-1";
    
    gameEnded = true;
    stopTimer();
    
    // Oyun sonucunu bildir
    if (gameId) {
      socket.emit("game_over", {
        gameId,
        result,
        reason: "checkmate"
      });
    }
    
    if (winner === 'w') {
      statusElement.innerText = "Şah mat! Beyaz kazandı.";
    } else {
      statusElement.innerText = "Şah mat! Siyah kazandı.";
    }
  }
  // Pat kontrolü
  else if (game.in_draw()) {
    gameEnded = true;
    stopTimer();
    
    // Oyun sonucunu bildir
    if (gameId) {
      socket.emit("game_over", {
        gameId,
        result: "1/2-1/2",
        reason: "draw"
      });
    }
    
    statusElement.innerText = "Beraberlik!";
  }
  // Şah kontrolü
  else if (game.in_check()) {
    const turn = game.turn() === 'w' ? "Beyaz" : "Siyah";
    statusElement.innerText = `${turn} şah altında!`;
  }
}

// Oyunu terk et
function resignGame() {
  if (!gameId || gameEnded) return;
  
  const result = playerColor === "white" ? "0-1" : "1-0";
  
  // Oyun sonucunu bildir
  socket.emit("game_over", {
    gameId,
    result,
    reason: "resignation"
  });
  
  gameEnded = true;
  stopTimer();
  
  statusElement.innerText = "Oyunu terk ettiniz.";
}

// Beraberlik teklif et
function offerDraw() {
  // Bu fonksiyon daha sonra eklenecek
  alert("Beraberlik teklifi özelliği henüz eklenmedi.");
}

// Chessboard başlat
board = Chessboard('board', {
  draggable: true,
  position: 'start',
  pieceTheme: 'img/chesspieces/wikipedia/{piece}.png',
  onDragStart,
  onDrop,
  onSnapEnd: () => board.position(game.fen())
});

function logout() {
  localStorage.removeItem("username");
  window.location.href = "login.html";
}

// Sayfa tamamen yüklendiğinde butonları ayarla
window.addEventListener("load", function() {
  // Eşleşme ara butonunu ayarla
  const findMatchBtn = document.getElementById("find-match-btn");
  if (findMatchBtn) {
    findMatchBtn.addEventListener("click", findMatch);
    console.log("Rakip ara butonu bağlandı");
  } else {
    console.error("find-match-btn bulunamadı!");
  }
  
  // Terk et butonunu ayarla
  const resignBtn = document.getElementById("resign-btn");
  if (resignBtn) {
    resignBtn.addEventListener("click", resignGame);
  }
  
  // Beraberlik teklif et butonunu ayarla
  const drawBtn = document.getElementById("draw-btn");
  if (drawBtn) {
    drawBtn.addEventListener("click", offerDraw);
  }
  
  // İptal butonunu ayarla
  const cancelMatchBtn = document.getElementById("cancel-match-btn");
  if (cancelMatchBtn) {
    cancelMatchBtn.addEventListener("click", function() {
      socket.emit("cancel_matchmaking", username);
      waitingOverlay.style.display = "none";
      statusElement.innerText = "Eşleşme iptal edildi.";
    });
  }
  
  // Süre seçimini ayarla
  const selectedTime = parseInt(timeSelect.value);
  whiteTime = selectedTime;
  blackTime = selectedTime;
  updateTimerDisplay();
});
