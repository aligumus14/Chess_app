// Satranç lobisi için JavaScript
const username = localStorage.getItem("username");
const token = localStorage.getItem("token");

const API_URL = "http://localhost:5000/api";
const socket = io("http://localhost:5000");

// DOM elementleri
const findMatchBtn = document.getElementById("find-match");
const cancelMatchBtn = document.getElementById("cancel-match");
const waitingMessage = document.getElementById("waiting-message");
const computerGameBtn = document.getElementById("computer-game");
const activePlayersList = document.getElementById("active-players");
const timeSelect = document.getElementById("time-select");
const difficultySelect = document.getElementById("difficulty-select");

// Socket.IO bağlantısı
socket.on("connect", () => {
  console.log("Socket.IO bağlantısı kuruldu");
  
  // Kullanıcı bağlantısını bildir
  socket.emit("user_connected", username);
});

// Aktif kullanıcılar güncellendiğinde
socket.on("active_users", (users) => {
  console.log("Aktif kullanıcılar:", users);
  updateActivePlayersList(users);
});

// Eşleşme bekleme
socket.on("waiting_for_match", () => {
  console.log("Eşleşme bekleniyor...");
  showWaitingUI();
});

// Eşleşme bulundu
socket.on("match_found", (data) => {
  console.log("Eşleşme bulundu:", data);
  
  // Eşleşme bilgilerini localStorage'a kaydet
  localStorage.setItem("gameId", data.gameId);
  localStorage.setItem("opponent", data.opponent);
  localStorage.setItem("playerColor", data.color);
  
  // Oyun sayfasına yönlendir
  window.location.href = "play.html";
});

// Eşleşme hatası
socket.on("match_error", (data) => {
  console.error("Eşleşme hatası:", data.message);
  hideWaitingUI();
  alert("Eşleşme hatası: " + data.message);
});

// Eşleşme iptal edildi
socket.on("matchmaking_cancelled", () => {
  console.log("Eşleşme iptal edildi");
  hideWaitingUI();
});

// Eşleşme ara
function findMatch() {
  const timeControl = parseInt(timeSelect.value);
  
  // Eşleşme aramayı başlat
  socket.emit("find_match", {
    username,
    timeControl
  });
  
  // Bekleme UI'ını göster
  showWaitingUI();
}

// Eşleşme aramayı iptal et
function cancelMatch() {
  socket.emit("cancel_matchmaking", username);
  hideWaitingUI();
}

// Bekleme UI'ını göster
function showWaitingUI() {
  findMatchBtn.style.display = "none";
  cancelMatchBtn.style.display = "inline-block";
  waitingMessage.style.display = "block";
}

// Bekleme UI'ını gizle
function hideWaitingUI() {
  findMatchBtn.style.display = "inline-block";
  cancelMatchBtn.style.display = "none";
  waitingMessage.style.display = "none";
}

// Bilgisayara karşı oyun başlat
function startComputerGame() {
  // Bilgisayar oyunu sayfasına yönlendir
  window.location.href = "computer.html";
}

// Aktif oyuncular listesini güncelle
function updateActivePlayersList(users) {
  // Kendimizi listeden çıkar
  const filteredUsers = users.filter(user => user !== username);
  
  // Listeyi temizle
  activePlayersList.innerHTML = "";
  
  // Kullanıcı yoksa mesaj göster
  if (filteredUsers.length === 0) {
    const li = document.createElement("li");
    li.textContent = "Aktif oyuncu bulunmuyor";
    li.className = "no-players";
    activePlayersList.appendChild(li);
    return;
  }
  
  // Her kullanıcı için liste elemanı oluştur
  filteredUsers.forEach(user => {
    const li = document.createElement("li");
    li.textContent = user;
    activePlayersList.appendChild(li);
  });
}

// Sayfa yüklendiğinde
window.addEventListener("load", function() {
  // Token kontrolü
  if (!token || !username) {
    alert("Giriş yapmalısınız.");
    window.location.href = "login.html";
    return;
  }
  
  // Butonları ayarla
  findMatchBtn.addEventListener("click", findMatch);
  cancelMatchBtn.addEventListener("click", cancelMatch);
  computerGameBtn.addEventListener("click", startComputerGame);
  
  // Başlangıçta bekleme UI'ını gizle
  hideWaitingUI();
});

// Çıkış yap
function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("username");
  window.location.href = "login.html";
}
