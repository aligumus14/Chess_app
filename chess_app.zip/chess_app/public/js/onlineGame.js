// Online satranç oyunu için JavaScript
const boardElement = document.getElementById("board");

// Token kontrolü
if (!TokenManager.isLoggedIn()) {
  alert("Giriş yapmalısınız.");
  window.location.href = "login.html";
}

const username = TokenManager.getUsername();
const token = TokenManager.getToken();

// Oyun bilgilerini localStorage'dan al
const gameId = localStorage.getItem("gameId");
const opponentName = localStorage.getItem("opponent");
const playerColor = localStorage.getItem("playerColor") || "white";

const API_URL = "http://localhost:5000/api";
const socket = io("http://localhost:5000");

const game = new Chess();
let board = null;

// Timer değişkenleri
let whiteTime = 600; // 10 dakika (saniye cinsinden)
let blackTime = 600;
let activeTimer = null;
let timerInterval = null;
let gameStarted = false;
let gameEnded = false;
let moveNumber = 1; // Hamle numarası
let firstMoveMade = false; // İlk hamle yapıldı mı?

// Timer elementleri
const whiteTimerElement = document.getElementById("white-time");
const blackTimerElement = document.getElementById("black-time");
const whiteTimerContainer = document.getElementById("white-timer");
const blackTimerContainer = document.getElementById("black-timer");
const resignButton = document.getElementById("resign-game");
const movesListElement = document.getElementById("moves-list");
const statusElement = document.getElementById("status");
const whitePlayerName = document.getElementById("white-player-name");
const blackPlayerName = document.getElementById("black-player-name");

// Pencere boyutu değiştiğinde tahtayı yeniden boyutlandır
window.addEventListener('resize', function() {
  if (board) {
    board.resize();
  }
});

// Socket.IO bağlantısı
socket.on("connect", () => {
  console.log("Socket.IO bağlantısı kuruldu");
  
  // Kullanıcı bağlantısını bildir
  socket.emit("user_connected", username);
  
  // Oyun bilgilerini kontrol et
  if (!gameId || !opponentName) {
    alert("Oyun bilgileri eksik. Lobiye yönlendiriliyorsunuz.");
    window.location.href = "lobby.html";
    return;
  }
  
  // Oyun odasına katıl
  socket.emit("join_game_room", { gameId, username });
  console.log(`Oyun odasına katılma isteği gönderildi: ${gameId}`);
  
  // Oyuncu adlarını ayarla
  if (playerColor === "white") {
    whitePlayerName.innerText = username;
    blackPlayerName.innerText = opponentName;
  } else {
    whitePlayerName.innerText = opponentName;
    blackPlayerName.innerText = username;
  }
  
  // Tahtayı doğru yönde göster
  board.orientation(playerColor);
  
  // Oyunu başlat
  resetGame();
  gameStarted = true;
  
  // Beyaz başlar
  if (playerColor === "white") {
    statusElement.innerText = "Sizin sıranız (Beyaz)";
  } else {
    statusElement.innerText = "Rakibin sırası (Beyaz)";
  }
});

// Rakip hamle yaptığında
socket.on("opponent_move", (data) => {
  console.log("Rakip hamle yaptı:", data);
  
  // İlk hamle yapıldıysa ve timer başlamadıysa, timer'ı başlat
  if (!firstMoveMade) {
    firstMoveMade = true;
    startTimer(game.turn());
  }
  
  // Hamleyi yap
  const move = game.move({
    from: data.move.from,
    to: data.move.to,
    promotion: data.move.promotion || 'q'
  });
  
  if (move) {
    // Tahtayı güncelle
    board.position(game.fen());
    
    // Hamleyi listeye ekle
    const moveColor = playerColor === "white" ? "b" : "w";
    addMoveToList(move, moveColor);
    
    // Sıra değişti, timer'ı güncelle
    const newTurn = game.turn();
    startTimer(newTurn);
    
    // Durum kontrolü
    checkGameStatus();
  }
});

// Broadcast ile gelen hamleleri de dinle (yedek mekanizma)
socket.on("opponent_move_broadcast", (data) => {
  console.log("Broadcast ile hamle alındı:", data);
  
  // Bu hamle bize mi gönderilmiş kontrol et
  if (data.targetUsername === username) {
    console.log("Bu hamle bize gönderilmiş, işleniyor...");
    
    // İlk hamle yapıldıysa ve timer başlamadıysa, timer'ı başlat
    if (!firstMoveMade) {
      firstMoveMade = true;
      startTimer(game.turn());
    }
    
    // Hamleyi yap
    const move = game.move({
      from: data.move.from,
      to: data.move.to,
      promotion: data.move.promotion || 'q'
    });
    
    if (move) {
      // Tahtayı güncelle
      board.position(game.fen());
      
      // Hamleyi listeye ekle
      const moveColor = playerColor === "white" ? "b" : "w";
      addMoveToList(move, moveColor);
      
      // Sıra değişti, timer'ı güncelle
      const newTurn = game.turn();
      startTimer(newTurn);
      
      // Durum kontrolü
      checkGameStatus();
    }
  }
});

// Oyun sona erdiğinde
socket.on("game_over", (data) => {
  console.log("Oyun bitti:", data);
  
  gameEnded = true;
  stopTimer();
  
  let resultMessage = "";
  
  if (data.reason === "checkmate") {
    if ((data.result === "1-0" && playerColor === "white") || 
        (data.result === "0-1" && playerColor === "black")) {
      resultMessage = "Tebrikler! Şah mat yaparak kazandınız.";
    } else {
      resultMessage = "Şah mat oldunuz. Rakibiniz kazandı.";
    }
  } else if (data.reason === "timeout") {
    if ((data.result === "1-0" && playerColor === "white") || 
        (data.result === "0-1" && playerColor === "black")) {
      resultMessage = "Rakibinizin süresi bitti. Kazandınız!";
    } else {
      resultMessage = "Süreniz bitti. Rakibiniz kazandı.";
    }
  } else if (data.reason === "resignation") {
    if ((data.result === "1-0" && playerColor === "white") || 
        (data.result === "0-1" && playerColor === "black")) {
      resultMessage = "Rakibiniz terk etti. Kazandınız!";
    } else {
      resultMessage = "Oyunu terk ettiniz. Rakibiniz kazandı.";
    }
  } else if (data.result === "1/2-1/2") {
    resultMessage = "Oyun berabere bitti.";
  }
  
  // ELO değişimini göster
  if (data.eloChange) {
    const eloChangeText = data.eloChange > 0 ? `+${data.eloChange}` : data.eloChange;
    resultMessage += ` ELO değişimi: ${eloChangeText}`;
  }
  
  statusElement.innerText = resultMessage;
  alert(resultMessage);
});

// Timer'ı başlat
function startTimer(color) {
  stopTimer(); // Önceki timer'ı durdur
  
  activeTimer = color;
  
  // Aktif timer'ı vurgula
  whiteTimerContainer.classList.remove("active");
  blackTimerContainer.classList.remove("active");
  
  if (color === "w") {
    whiteTimerContainer.classList.add("active");
    
    // Sıra kontrolü
    if (playerColor === "white") {
      statusElement.innerText = "Sizin sıranız (Beyaz)";
    } else {
      statusElement.innerText = "Rakibin sırası (Beyaz)";
    }
  } else {
    blackTimerContainer.classList.add("active");
    
    // Sıra kontrolü
    if (playerColor === "black") {
      statusElement.innerText = "Sizin sıranız (Siyah)";
    } else {
      statusElement.innerText = "Rakibin sırası (Siyah)";
    }
  }
  
  timerInterval = setInterval(() => {
    if (activeTimer === "w") {
      whiteTime--;
      if (whiteTime <= 30) { // Son 30 saniye
        whiteTimerContainer.classList.add("danger");
      }
      if (whiteTime <= 0) {
        timeOut("w");
      }
    } else {
      blackTime--;
      if (blackTime <= 30) { // Son 30 saniye
        blackTimerContainer.classList.add("danger");
      }
      if (blackTime <= 0) {
        timeOut("b");
      }
    }
    updateTimerDisplay();
  }, 1000);
}

// Timer'ı durdur
function stopTimer() {
  clearInterval(timerInterval);
  timerInterval = null;
}

// Süre bittiğinde
function timeOut(color) {
  stopTimer();
  gameEnded = true;
  
  // Oyun sonucunu bildir
  if (gameId) {
    const result = color === "w" ? "0-1" : "1-0"; // Beyaz süre bittiyse siyah kazanır, tersi de geçerli
    socket.emit("game_over", {
      gameId,
      result,
      reason: "timeout"
    });
  }
  
  if (color === "w") {
    statusElement.innerText = "Beyazın süresi bitti! Siyah kazandı.";
  } else {
    statusElement.innerText = "Siyahın süresi bitti! Beyaz kazandı.";
  }
}

// Timer göstergesini güncelle
function updateTimerDisplay() {
  whiteTimerElement.innerText = formatTime(whiteTime);
  blackTimerElement.innerText = formatTime(blackTime);
}

// Süreyi formatla (mm:ss)
function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
}

// Oyunu sıfırla
function resetGame() {
  game.reset();
  board.position('start');
  
  // Timer'ları sıfırla
  stopTimer();
  gameEnded = false;
  firstMoveMade = false;
  
  
  
  resignButton.style.display = "inline-block";
  
  // Hamle listesini sıfırla
  resetMovesList();
}

// Hamle listesini sıfırla
function resetMovesList() {
  movesListElement.innerHTML = "";
  moveNumber = 1;
}

// Hamle listesine hamle ekle
function addMoveToList(move, color) {
  // Hamle SAN notasyonunu al
  const san = move.san;
  
  // Eğer beyaz hamle ise yeni satır oluştur
  if (color === 'w') {
    const row = document.createElement('tr');
    row.id = `move-${moveNumber}`;
    row.innerHTML = `
      <td>${moveNumber}.</td>
      <td>${san}</td>
      <td></td>
    `;
    movesListElement.appendChild(row);
  } 
  // Eğer siyah hamle ise mevcut satırı güncelle
  else {
    const row = document.getElementById(`move-${moveNumber}`);
    if (row) {
      const cells = row.getElementsByTagName('td');
      if (cells.length > 2) {
        cells[2].textContent = san;
      }
      moveNumber++;
    }
  }
  
  // Hamle listesini en alta kaydır
  const moveList = document.querySelector('.move-list');
  moveList.scrollTop = moveList.scrollHeight;
}

function onDragStart(source, piece) {
  // Oyun bittiyse hamle yapılamaz
  if (game.game_over() || gameEnded) return false;
  
  // Sıra kontrolü
  const turn = game.turn();
  
  // Eğer oyuncunun rengi beyaz ve sıra beyazda değilse veya
  // oyuncunun rengi siyah ve sıra siyahta değilse hamle yapılamaz
  if ((playerColor === "white" && turn === 'b') || 
      (playerColor === "black" && turn === 'w')) {
    return false;
  }
  
  // Doğru renkteki taşları hareket ettir
  if (turn === 'w' && piece.search(/^b/) !== -1) return false;
  if (turn === 'b' && piece.search(/^w/) !== -1) return false;
}

function onDrop(source, target) {
  // Hamleyi yap
  const move = game.move({ 
    from: source, 
    to: target, 
    promotion: 'q' // Şimdilik otomatik vezir terfi
  });
  
  // Geçersiz hamle
  if (move === null) return 'snapback';

  // İlk hamle yapıldıysa ve timer başlamadıysa, timer'ı başlat
  if (!firstMoveMade) {
    firstMoveMade = true;
    startTimer(game.turn());
  }

  // Hamleyi listeye ekle
  const moveColor = playerColor === "white" ? "w" : "b";
  addMoveToList(move, moveColor);

  // Hamleyi socket üzerinden gönder
  socket.emit("make_move", {
    gameId,
    move: {
      from: source,
      to: target,
      promotion: move.promotion
    },
    fen: game.fen(),
    remainingTime: playerColor === "white" ? whiteTime : blackTime
  });
  
  // Sıra değişti, timer'ı güncelle
  const newTurn = game.turn();
  startTimer(newTurn);
  
  // Durum kontrolü
  checkGameStatus();
}

// Oyun durumunu kontrol et
function checkGameStatus() {
  // Şah mat kontrolü
  if (game.in_checkmate()) {
    const winner = game.turn() === 'w' ? 'b' : 'w';
    const result = winner === 'w' ? "1-0" : "0-1";
    
    gameEnded = true;
    stopTimer();
    
    // Oyun sonucunu bildir
    if (gameId) {
      socket.emit("game_over", {
        gameId,
        result,
        reason: "checkmate"
      });
    }
    
    if (winner === 'w') {
      statusElement.innerText = "Şah mat! Beyaz kazandı.";
    } else {
      statusElement.innerText = "Şah mat! Siyah kazandı.";
    }
  }
  // Pat kontrolü
  else if (game.in_draw()) {
    gameEnded = true;
    stopTimer();
    
    // Oyun sonucunu bildir
    if (gameId) {
      socket.emit("game_over", {
        gameId,
        result: "1/2-1/2",
        reason: "draw"
      });
    }
    
    statusElement.innerText = "Beraberlik!";
  }
  // Şah kontrolü
  else if (game.in_check()) {
    const turn = game.turn() === 'w' ? "Beyaz" : "Siyah";
    statusElement.innerText = `${turn} şah altında!`;
  }
}


// Oyunu terk et
function resignGame() {
  if (!gameId || gameEnded) return;
  
  if (confirm("Oyunu terk etmek istediğinize emin misiniz?")) {
    const result = playerColor === "white" ? "0-1" : "1-0";
    
    // Oyun sonucunu bildir
    socket.emit("game_over", {
      gameId,
      result,
      reason: "resignation"
    });
    
    gameEnded = true;
    stopTimer();
    
    statusElement.innerText = "Oyunu terk ettiniz.";
  }
}

// Chessboard başlat
board = Chessboard('board', {
  draggable: true,
  position: 'start',
  pieceTheme: 'img/chesspieces/wikipedia/{piece}.png',
  onDragStart,
  onDrop,
  onSnapEnd: () => board.position(game.fen())
});

// Sayfa yüklendiğinde
window.addEventListener("load", function() {
  // Token kontrolü tekrar yap
  if (!TokenManager.isLoggedIn()) {
    alert("Giriş yapmalısınız.");
    window.location.href = "login.html";
    return;
  }
  
  // Terk et butonunu ayarla
  resignButton.addEventListener("click", resignGame);
  
  // Oyun bilgilerini kontrol et
  if (!gameId || !opponentName) {
    alert("Oyun bilgileri eksik. Lobiye yönlendiriliyorsunuz.");
    window.location.href = "lobby.html";
    return;
  }
});

// Lobiye dön
function backToLobby() {
  if (gameStarted && !gameEnded) {
    if (confirm("Devam eden oyunu terk etmek istediğinize emin misiniz?")) {
      resignGame();
    } else {
      return;
    }
  }
  
  // Oyun bilgilerini temizle
  localStorage.removeItem("gameId");
  localStorage.removeItem("opponent");
  localStorage.removeItem("playerColor");
  
  // Lobiye yönlendir
  window.location.href = "lobby.html";
}

// Çıkış yap
function logout() {
  TokenManager.logout();
}
