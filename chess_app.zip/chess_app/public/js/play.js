const boardElement = document.getElementById("board");
const username = localStorage.getItem("username");
document.getElementById("white-player-name").innerText = username;

const API_URL = "http://localhost:5000/api/games";
let gameId = null;

const game = new Chess();
let board = null;

// Timer değişkenleri
let whiteTime = 600; // 10 dakika (saniye cinsinden)
let blackTime = 600;
let activeTimer = null;
let timerInterval = null;
let gameStarted = false;
let gameEnded = false;
let moveNumber = 1; // Hamle numarası

// Timer elementleri
const whiteTimerElement = document.getElementById("white-time");
const blackTimerElement = document.getElementById("black-time");
const whiteTimerContainer = document.getElementById("white-timer");
const blackTimerContainer = document.getElementById("black-timer");
const startTimerButton = document.getElementById("start-timer");
const resetTimerButton = document.getElementById("reset-timer");
const timeSelect = document.getElementById("time-select");
const movesListElement = document.getElementById("moves-list");

// Pencere boyutu değiştiğinde tahtayı yeniden boyutlandır
window.addEventListener('resize', function() {
  if (board) {
    board.resize();
  }
});

// Timer başlatma butonu
startTimerButton.addEventListener("click", () => {
  if (!gameStarted) {
    gameStarted = true;
    startTimerButton.disabled = true;
    timeSelect.disabled = true;
    startTimer("w"); // Beyaz başlar
  }
});

// Timer sıfırlama butonu
resetTimerButton.addEventListener("click", () => {
  resetTimers();
  resetMovesList();
});

// Süre seçimi değiştiğinde
timeSelect.addEventListener("change", () => {
  const selectedTime = parseInt(timeSelect.value);
  whiteTime = selectedTime;
  blackTime = selectedTime;
  updateTimerDisplay();
});

// Timer'ı başlat
function startTimer(color) {
  stopTimer(); // Önceki timer'ı durdur
  
  activeTimer = color;
  
  // Aktif timer'ı vurgula
  whiteTimerContainer.classList.remove("active");
  blackTimerContainer.classList.remove("active");
  
  if (color === "w") {
    whiteTimerContainer.classList.add("active");
  } else {
    blackTimerContainer.classList.add("active");
  }
  
  timerInterval = setInterval(() => {
    if (activeTimer === "w") {
      whiteTime--;
      if (whiteTime <= 30) { // Son 30 saniye
        whiteTimerContainer.classList.add("danger");
      }
      if (whiteTime <= 0) {
        timeOut("w");
      }
    } else {
      blackTime--;
      if (blackTime <= 30) { // Son 30 saniye
        blackTimerContainer.classList.add("danger");
      }
      if (blackTime <= 0) {
        timeOut("b");
      }
    }
    updateTimerDisplay();
  }, 1000);
}

// Timer'ı durdur
function stopTimer() {
  clearInterval(timerInterval);
  timerInterval = null;
}

// Süre bittiğinde
function timeOut(color) {
  stopTimer();
  gameEnded = true;
  
  if (color === "w") {
    alert("Süreniz bitti! Siyah kazandı.");
    document.getElementById("status").innerText = "Süre bitti! Siyah kazandı.";
    finishGame("0-1", "timeout");
  } else {
    alert("Bilgisayarın süresi bitti! Beyaz kazandı.");
    document.getElementById("status").innerText = "Süre bitti! Beyaz kazandı.";
    finishGame("1-0", "timeout");
  }
}

// Timer göstergesini güncelle
function updateTimerDisplay() {
  whiteTimerElement.innerText = formatTime(whiteTime);
  blackTimerElement.innerText = formatTime(blackTime);
}

// Süreyi formatla (mm:ss)
function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
}

// Timer'ları sıfırla
function resetTimers() {
  stopTimer();
  gameStarted = false;
  gameEnded = false;
  
  const selectedTime = parseInt(timeSelect.value);
  whiteTime = selectedTime;
  blackTime = selectedTime;
  
  whiteTimerContainer.classList.remove("active", "danger");
  blackTimerContainer.classList.remove("active", "danger");
  
  startTimerButton.disabled = false;
  timeSelect.disabled = false;
  
  updateTimerDisplay();
}

// Hamle listesini sıfırla
function resetMovesList() {
  movesListElement.innerHTML = "";
  moveNumber = 1;
}

// Hamle listesine hamle ekle
function addMoveToList(move, color) {
  // Hamle SAN notasyonunu al
  const san = move.san;
  
  // Eğer beyaz hamle ise yeni satır oluştur
  if (color === 'w') {
    const row = document.createElement('tr');
    row.id = `move-${moveNumber}`;
    row.innerHTML = `
      <td>${moveNumber}.</td>
      <td>${san}</td>
      <td></td>
    `;
    movesListElement.appendChild(row);
  } 
  // Eğer siyah hamle ise mevcut satırı güncelle
  else {
    const row = document.getElementById(`move-${moveNumber}`);
    if (row) {
      const cells = row.getElementsByTagName('td');
      if (cells.length > 2) {
        cells[2].textContent = san;
      }
      moveNumber++;
    }
  }
  
  // Hamle listesini en alta kaydır
  const moveList = document.querySelector('.move-list');
  moveList.scrollTop = moveList.scrollHeight;
}

async function startGame() {
  const res = await fetch(`${API_URL}/create`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ whitePlayer: username, blackPlayer: "computer" })
  });
  const data = await res.json();
  gameId = data._id;
  console.log("Oyun ID:", gameId);
  
  // Başlangıçta timer'ları ayarla
  const selectedTime = parseInt(timeSelect.value);
  whiteTime = selectedTime;
  blackTime = selectedTime;
  updateTimerDisplay();
  
  // Hamle listesini sıfırla
  resetMovesList();
}

function onDragStart(source, piece) {
  // Oyun bittiyse veya timer başlamadıysa hamle yapılamaz
  if (game.game_over() || gameEnded || !gameStarted) return false;
  
  // Sıra kimde kontrolü
  if (game.turn() === 'w' && piece.search(/^b/) !== -1) return false;
  if (game.turn() === 'b' && piece.search(/^w/) !== -1) return false;
}

function onDrop(source, target) {
  const move = game.move({ from: source, to: target, promotion: 'q' });
  if (move === null) return 'snapback';

  // Hamleyi listeye ekle
  addMoveToList(move, 'w');

  // Hamle yapıldı, timer'ı değiştir
  if (gameStarted && !gameEnded) {
    // İnsan hamlesinden sonra bilgisayarın süresi başlamalı
    startTimer('b');
  }

  updateStatus();
  board.position(game.fen());

  // Hamleyi backend'e gönder
  if (gameId) {
    fetch(`${API_URL}/move/${gameId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ move: move.san })
    });
  }
  
  // Bilgisayar için rastgele hamle (demo amaçlı)
  if (game.turn() === 'b' && !game.game_over() && !gameEnded) {
    setTimeout(() => {
      const moves = game.moves();
      if (moves.length > 0) {
        const randomMove = moves[Math.floor(Math.random() * moves.length)];
        const computerMove = game.move(randomMove);
        
        // Bilgisayar hamlesini listeye ekle
        addMoveToList(computerMove, 'b');
        
        board.position(game.fen());
        updateStatus();
        
        // Bilgisayar hamle yaptı, timer'ı değiştir
        if (gameStarted && !gameEnded) {
          startTimer('w');
        }
      }
    }, 1000); // Bilgisayarın düşünmesi için biraz daha uzun süre
  }
}

function updateStatus() {
  let status = '';
  const moveColor = game.turn() === 'w' ? 'Beyaz' : 'Siyah';

  if (game.in_checkmate()) {
    status = `Mat! ${moveColor === 'Beyaz' ? 'Siyah' : 'Beyaz'} kazandı.`;
    gameEnded = true;
    stopTimer();
  } else if (game.in_draw()) {
    status = "Beraberlik.";
    gameEnded = true;
    stopTimer();
  } else {
    status = `${moveColor}'ın sırası.`;
    if (game.in_check()) {
      status += " Şah var!";
    }
  }
  document.getElementById("status").innerText = status;
}

function finishGame(result = null, reason = null) {
  if (!gameId) return;
  
  // Timer'ı durdur
  stopTimer();
  gameEnded = true;
  
  // Sonucu belirle
  let gameResult = "1/2-1/2"; // Varsayılan beraberlik
  
  if (result) {
    // Eğer sonuç parametresi verilmişse (timeout durumu)
    gameResult = result;
  } else if (game.in_checkmate()) {
    gameResult = game.turn() === 'w' ? "0-1" : "1-0";
  }

  fetch(`${API_URL}/finish/${gameId}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ 
      result: gameResult,
      reason: reason || "normal"
    })
  }).then(() => {
    alert("Oyun kaydedildi!");
  });
}

// Chessboard başlat
board = Chessboard('board', {
  draggable: true,
  position: 'start',
  pieceTheme: 'img/chesspieces/wikipedia/{piece}.png',
  onDragStart,
  onDrop,
  onSnapEnd: () => board.position(game.fen())
});

function logout() {
  localStorage.removeItem("username");
  window.location.href = "login.html";
}

// Oyunu başlat
startGame();
updateStatus();
updateTimerDisplay();
