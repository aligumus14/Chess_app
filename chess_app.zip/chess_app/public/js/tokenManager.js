// Merkezi token yönetimi için yardımcı fonksiyonlar
const TokenManager = {
  // Token'ı localStorage'a kaydet
  saveToken: function(token) {
    localStorage.setItem("token", token);
  },
  
  // Token'ı localStorage'dan al
  getToken: function() {
    return localStorage.getItem("token");
  },
  
  // Token'ı localStorage'dan sil
  removeToken: function() {
    localStorage.removeItem("token");
  },
  
  // Kullanıcı adını localStorage'a kaydet
  saveUsername: function(username) {
    localStorage.setItem("username", username);
  },
  
  // Kullanıcı adını localStorage'dan al
  getUsername: function() {
    return localStorage.getItem("username");
  },
  
  // Kullanıcı adını localStorage'dan sil
  removeUsername: function() {
    localStorage.removeItem("username");
  },
  
  // Kullanıcının giriş yapmış olup olmadığını kontrol et
  isLoggedIn: function() {
    return this.getToken() && this.getUsername();
  },
  
  // Giriş kontrolü yap, giriş yapılmamışsa login sayfasına yönlendir
  checkLogin: function() {
    if (!this.isLoggedIn()) {
      alert("Giriş yapmalısınız.");
      window.location.href = "login.html";
      return false;
    }
    return true;
  },
  
  // Çıkış yap
  logout: function() {
    this.removeToken();
    this.removeUsername();
    window.location.href = "login.html";
  }
};

// Sayfa yüklendiğinde otomatik giriş kontrolü yap
document.addEventListener("DOMContentLoaded", function() {
  // Login ve register sayfalarında kontrol yapma
  const currentPage = window.location.pathname.split("/").pop();
  if (currentPage !== "login.html" && currentPage !== "register.html" && currentPage !== "index.html") {
    TokenManager.checkLogin();
  }
});
