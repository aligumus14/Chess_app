const API_URL = "http://localhost:5000/api/auth";

document.addEventListener("DOMContentLoaded", () => {
  const registerForm = document.getElementById("registerForm");
  const loginForm = document.getElementById("loginForm");

  if (registerForm) {
    registerForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const username = document.getElementById("username").value;
      const password = document.getElementById("password").value;

      const res = await fetch(`${API_URL}/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });

      const data = await res.json();
      const messageEl = document.getElementById("message");
      messageEl.innerText = data.message;
      
      // Başarılı kayıt için sınıf ekle
      if (res.ok) {
        messageEl.className = "success-message";
        setTimeout(() => window.location.href = "login.html", 1000);
      } else {
        messageEl.className = "error-message";
      }
    });
  }

  if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const username = document.getElementById("username").value;
      const password = document.getElementById("password").value;

      const res = await fetch(`${API_URL}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });

      const data = await res.json();
      const messageEl = document.getElementById("message");
      messageEl.innerText = data.message;

      if (res.ok) {
        messageEl.className = "success-message";
        // TokenManager kullanarak token ve kullanıcı adını kaydet
        TokenManager.saveUsername(data.user.username);
        TokenManager.saveToken(data.token);
        // Giriş sonrası home.html'e yönlendir
        setTimeout(() => window.location.href = "home.html", 1000);
      } else {
        messageEl.className = "error-message";
      }
    });
  }
});

// Global logout fonksiyonu
function logout() {
  // TokenManager kullanarak çıkış yap
  TokenManager.logout();
}
