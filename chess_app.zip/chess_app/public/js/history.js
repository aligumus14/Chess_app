// Oyun geçmişi için JavaScript
const username = localStorage.getItem("username");
const token = localStorage.getItem("token");

const API_URL = "http://localhost:5000/api";

// DOM elementleri
const gamesList = document.getElementById("games-list");
const paginationContainer = document.getElementById("pagination");
const loadingIndicator = document.getElementById("loading");

// Sayfalama değişkenleri
let currentPage = 1;
let totalPages = 1;
const gamesPerPage = 10;

// Oyun geçmişini getir
async function fetchGameHistory(page = 1) {
  try {
    showLoading(true);
    
    const skip = (page - 1) * gamesPerPage;
    const res = await fetch(`${API_URL}/history/user/${username}?limit=${gamesPerPage}&skip=${skip}`, {
      headers: { 
        "Authorization": `Bearer ${token}`
      }
    });
    
    if (!res.ok) {
      throw new Error("Oyun geçmişi getirilemedi");
    }
    
    const data = await res.json();
    
    // Sayfalama bilgilerini güncelle
    currentPage = data.currentPage;
    totalPages = data.totalPages;
    
    // Oyunları listele
    displayGames(data.games);
    
    // Sayfalama kontrollerini güncelle
    updatePagination();
    
    showLoading(false);
  } catch (err) {
    console.error("Oyun geçmişi getirme hatası:", err);
    showError("Oyun geçmişi yüklenirken bir hata oluştu.");
    showLoading(false);
  }
}

// Oyunları listele
function displayGames(games) {
  // Listeyi temizle
  gamesList.innerHTML = "";
  
  // Oyun yoksa mesaj göster
  if (games.length === 0) {
    const noGamesMessage = document.createElement("div");
    noGamesMessage.className = "no-games";
    noGamesMessage.textContent = "Henüz oynadığınız bir oyun bulunmuyor.";
    gamesList.appendChild(noGamesMessage);
    return;
  }
  
  // Her oyun için kart oluştur
  games.forEach(game => {
    const gameCard = document.createElement("div");
    gameCard.className = "game-card";
    
    // Oyun sonucuna göre renk sınıfı ekle
    if ((game.result === "1-0" && game.whitePlayer === username) || 
        (game.result === "0-1" && game.blackPlayer === username)) {
      gameCard.classList.add("win");
    } else if (game.result === "1/2-1/2") {
      gameCard.classList.add("draw");
    } else {
      gameCard.classList.add("loss");
    }
    
    // Oyun tarihini formatla
    const gameDate = new Date(game.endTime).toLocaleString();
    
    // Rakip adını belirle
    const opponent = game.whitePlayer === username ? game.blackPlayer : game.whitePlayer;
    
    // ELO değişimini belirle
    let eloChange = 0;
    if (game.eloChange) {
      eloChange = game.whitePlayer === username ? game.eloChange.white : game.eloChange.black;
    }
    
    // Oyun sonucunu metin olarak belirle
    let resultText = "";
    if (game.result === "1-0") {
      resultText = game.whitePlayer === username ? "Kazandınız" : "Kaybettiniz";
    } else if (game.result === "0-1") {
      resultText = game.blackPlayer === username ? "Kazandınız" : "Kaybettiniz";
    } else if (game.result === "1/2-1/2") {
      resultText = "Berabere";
    }
    
    // Oyun bitiş nedenini belirle
    let reasonText = "";
    switch (game.reason) {
      case "checkmate":
        reasonText = "Şah Mat";
        break;
      case "timeout":
        reasonText = "Süre Bitti";
        break;
      case "resignation":
        reasonText = "Terk Edildi";
        break;
      case "draw":
        reasonText = "Beraberlik";
        break;
      default:
        reasonText = "Normal";
    }
    
    // Oyun kartı içeriğini oluştur
    gameCard.innerHTML = `
      <div class="game-header">
        <span class="game-date">${gameDate}</span>
        <span class="game-result ${game.result.replace(/\//g, '-')}">${resultText}</span>
      </div>
      <div class="game-details">
        <div class="players">
          <div class="white-player ${game.whitePlayer === username ? 'you' : ''}">
            <span class="piece">♔</span>
            <span class="name">${game.whitePlayer}</span>
            <span class="elo">${game.whiteElo}</span>
          </div>
          <div class="vs">vs</div>
          <div class="black-player ${game.blackPlayer === username ? 'you' : ''}">
            <span class="piece">♚</span>
            <span class="name">${game.blackPlayer}</span>
            <span class="elo">${game.blackElo}</span>
          </div>
        </div>
        <div class="game-info">
          <div class="reason">
            <span class="label">Bitiş:</span>
            <span class="value">${reasonText}</span>
          </div>
          <div class="time-control">
            <span class="label">Süre:</span>
            <span class="value">${formatTimeControl(game.timeControl)}</span>
          </div>
          <div class="elo-change ${eloChange > 0 ? 'positive' : eloChange < 0 ? 'negative' : ''}">
            <span class="label">ELO:</span>
            <span class="value">${eloChange > 0 ? '+' : ''}${eloChange}</span>
          </div>
        </div>
      </div>
      <div class="game-actions">
        <button class="btn secondary view-game" data-id="${game._id}">Oyunu İncele</button>
      </div>
    `;
    
    // Oyun inceleme butonuna tıklama olayı ekle
    const viewButton = gameCard.querySelector(".view-game");
    viewButton.addEventListener("click", () => {
      viewGame(game._id);
    });
    
    gamesList.appendChild(gameCard);
  });
}

// Sayfalama kontrollerini güncelle
function updatePagination() {
  paginationContainer.innerHTML = "";
  
  // Sayfa sayısı 1'den fazlaysa sayfalama göster
  if (totalPages > 1) {
    // Önceki sayfa butonu
    const prevButton = document.createElement("button");
    prevButton.className = "pagination-btn prev";
    prevButton.textContent = "Önceki";
    prevButton.disabled = currentPage === 1;
    prevButton.addEventListener("click", () => {
      if (currentPage > 1) {
        fetchGameHistory(currentPage - 1);
      }
    });
    paginationContainer.appendChild(prevButton);
    
    // Sayfa numaraları
    const startPage = Math.max(1, currentPage - 2);
    const endPage = Math.min(totalPages, startPage + 4);
    
    for (let i = startPage; i <= endPage; i++) {
      const pageButton = document.createElement("button");
      pageButton.className = `pagination-btn page ${i === currentPage ? 'active' : ''}`;
      pageButton.textContent = i;
      pageButton.addEventListener("click", () => {
        fetchGameHistory(i);
      });
      paginationContainer.appendChild(pageButton);
    }
    
    // Sonraki sayfa butonu
    const nextButton = document.createElement("button");
    nextButton.className = "pagination-btn next";
    nextButton.textContent = "Sonraki";
    nextButton.disabled = currentPage === totalPages;
    nextButton.addEventListener("click", () => {
      if (currentPage < totalPages) {
        fetchGameHistory(currentPage + 1);
      }
    });
    paginationContainer.appendChild(nextButton);
  }
}

// Oyun inceleme sayfasına git
function viewGame(gameId) {
  // Oyun inceleme sayfasına yönlendir
  window.location.href = `game-viewer.html?id=${gameId}`;
}

// Süre kontrolünü formatla (saniyeden dakika:saniye formatına)
function formatTimeControl(seconds) {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

// Yükleniyor göstergesini göster/gizle
function showLoading(isLoading) {
  if (loadingIndicator) {
    loadingIndicator.style.display = isLoading ? "block" : "none";
  }
}

// Hata mesajı göster
function showError(message) {
  const errorElement = document.createElement("div");
  errorElement.className = "error-message";
  errorElement.textContent = message;
  
  // Varsa önceki hata mesajını kaldır
  const existingError = document.querySelector(".error-message");
  if (existingError) {
    existingError.remove();
  }
  
  // Hata mesajını ekle
  gamesList.parentNode.insertBefore(errorElement, gamesList);
  
  // 5 saniye sonra hata mesajını kaldır
  setTimeout(() => {
    errorElement.remove();
  }, 5000);
}

// Sayfa yüklendiğinde
window.addEventListener("load", function() {
  // Token kontrolü
  if (!token || !username) {
    alert("Giriş yapmalısınız.");
    window.location.href = "login.html";
    return;
  }
  
  // Oyun geçmişini getir
  fetchGameHistory();
});

// Çıkış yap
function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("username");
  window.location.href = "login.html";
}
