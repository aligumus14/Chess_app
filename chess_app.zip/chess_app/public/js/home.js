// public/js/home.js

const API_URL = "http://localhost:5000/api";
const token = localStorage.getItem("token");

// Token kontrolü
if (!token) {
  alert("Giriş yapmalısınız.");
  window.location.href = "login.html";
}

// Mesaj gösterimi
function showMessage(msg) {
  const messageEl = document.getElementById("message");
  messageEl.innerText = msg;
  messageEl.style.color = "red";
}

// Kullanıcı bilgilerini çek
async function fetchProfile() {
  try {
    const res = await fetch(`${API_URL}/auth/profile`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    const data = await res.json();
    document.getElementById("username").innerText = data.user?.username || "Bilinmeyen";
  } catch (err) {
    showMessage("Profil getirilirken hata oluştu");
  }
}

// Oyunları çek
async function fetchGames() {
  try {
    const res = await fetch(`${API_URL}/games/mine`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    const data = await res.json();
    const list = document.getElementById("gamesList");
    list.innerHTML = "";

    data.games.forEach(game => {
      const white = game.whitePlayer?.username || "Bilinmeyen";
      const black = game.blackPlayer?.username || "Bilinmeyen";
      const result = game.result || "Devam ediyor";

      const li = document.createElement("li");
      li.innerHTML = `
        <span>${white} vs ${black} → ${result}</span>
        <a href="game.html?gameId=${game._id}">Oyna</a>
      `;
      list.appendChild(li);
    });
  } catch (err) {
    showMessage("Oyunlar getirilemedi");
  }
}

// Yeni oyun başlat
async function startGame() {
  const opponentId = document.getElementById("opponentId").value;
  const color = document.getElementById("color").value;

  if (!opponentId) return showMessage("Rakip ID girilmeli");

  try {
    const res = await fetch(`${API_URL}/games/start`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ opponentId, color })
    });

    const data = await res.json();
    showMessage(data.message);

    if (res.ok) {
      fetchGames(); // Listeyi güncelle
    }
  } catch (err) {
    showMessage("Oyun başlatılamadı");
  }
}

// Sayfa yüklenince çalıştır
fetchProfile();
fetchGames();
