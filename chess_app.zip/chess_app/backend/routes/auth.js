const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const User = require("../models/User");

// Kayıt
router.post("/register", async (req, res) => {
  try {
    const { username, password } = req.body;
    const existingUser = await User.findOne({ username });
    if (existingUser) return res.status(400).json({ message: "Kullanıcı adı zaten var." });

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ username, password: hashedPassword });
    await newUser.save();
    res.status(201).json({ message: "Kayıt başarılı." });
  } catch (err) {
    res.status(500).json({ message: "Sunucu hatası." });
  }
});

// Giriş
router.post("/login", async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user) return res.status(400).json({ message: "Kullanıcı bulunamadı." });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ message: "Şifre hatalı." });

    // Basit token gibi sadece kullanıcı adı gönderiyoruz (JWT yok)
    res.status(200).json({ message: "Giriş başarılı", user: { username: user.username } });
  } catch (err) {
    res.status(500).json({ message: "Sunucu hatası." });
  }
});

module.exports = router;
