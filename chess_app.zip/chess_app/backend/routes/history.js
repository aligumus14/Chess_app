const express = require("express");
const router = express.Router();
const Game = require("../models/Game");
const User = require("../models/User");

// Kullanıcının oyun geçmişini getir
router.get("/user/:username", async (req, res) => {
  try {
    const { username } = req.params;
    const { limit = 10, skip = 0 } = req.query;
    
    // Kullanıcının oynadığı tüm oyunları bul (beyaz veya siyah olarak)
    const games = await Game.find({
      $or: [
        { whitePlayer: username },
        { blackPlayer: username }
      ],
      result: { $ne: "ongoing" } // Sadece bitmiş oyunları getir
    })
    .sort({ endTime: -1 }) // En son oyunlar önce
    .skip(parseInt(skip))
    .limit(parseInt(limit));
    
    // Toplam oyun sayısını da getir (sayfalama için)
    const totalGames = await Game.countDocuments({
      $or: [
        { whitePlayer: username },
        { blackPlayer: username }
      ],
      result: { $ne: "ongoing" }
    });
    
    res.status(200).json({
      games,
      totalGames,
      currentPage: Math.floor(parseInt(skip) / parseInt(limit)) + 1,
      totalPages: Math.ceil(totalGames / parseInt(limit))
    });
  } catch (err) {
    console.error("Oyun geçmişi getirme hatası:", err);
    res.status(500).json({ message: "Oyun geçmişi getirilemedi." });
  }
});

// Belirli bir oyunun detaylarını getir
router.get("/detail/:gameId", async (req, res) => {
  try {
    const { gameId } = req.params;
    
    const game = await Game.findById(gameId);
    if (!game) {
      return res.status(404).json({ message: "Oyun bulunamadı." });
    }
    
    res.status(200).json(game);
  } catch (err) {
    console.error("Oyun detayı getirme hatası:", err);
    res.status(500).json({ message: "Oyun detayı getirilemedi." });
  }
});

// Oyunu sonlandır ve sonucu kaydet
router.post("/finish/:gameId", async (req, res) => {
  try {
    const { gameId } = req.params;
    const { result, reason } = req.body;
    
    const game = await Game.findById(gameId);
    if (!game) {
      return res.status(404).json({ message: "Oyun bulunamadı." });
    }
    
    // Oyun zaten bittiyse tekrar işlem yapma
    if (game.result !== "ongoing") {
      return res.status(400).json({ message: "Bu oyun zaten sonlandırılmış." });
    }
    
    // Oyun sonucunu güncelle
    game.result = result;
    game.endTime = Date.now();
    game.reason = reason || "normal";
    
    // Bilgisayara karşı oyun değilse ELO hesapla
    let eloChange = 0;
    
    if (!game.blackPlayer.startsWith("Computer_") && !game.whitePlayer.startsWith("Computer_")) {
      // Kazananı ve kaybedeni belirle
      let winner, loser, winnerElo, loserElo;
      
      if (result === "1-0") {
        // Beyaz kazandı
        winner = game.whitePlayer;
        loser = game.blackPlayer;
        winnerElo = game.whiteElo;
        loserElo = game.blackElo;
      } else if (result === "0-1") {
        // Siyah kazandı
        winner = game.blackPlayer;
        loser = game.whitePlayer;
        winnerElo = game.blackElo;
        loserElo = game.whiteElo;
      }
      
      // Beraberlik değilse ELO hesapla
      if (winner && loser) {
        // ELO değişimini hesapla
        eloChange = calculateEloChange(winnerElo, loserElo);
        
        // ELO değişimini kaydet
        game.eloChange = {
          white: result === "1-0" ? eloChange : -eloChange,
          black: result === "0-1" ? eloChange : -eloChange
        };
        
        // Kullanıcıların ELO ve istatistiklerini güncelle
        const winnerUser = await User.findOne({ username: winner });
        const loserUser = await User.findOne({ username: loser });
        
        if (winnerUser) {
          winnerUser.elo += eloChange;
          winnerUser.wins += 1;
          winnerUser.gamesPlayed += 1;
          await winnerUser.save();
        }
        
        if (loserUser) {
          loserUser.elo = Math.max(100, loserUser.elo - eloChange); // ELO 100'ün altına düşmesin
          loserUser.losses += 1;
          loserUser.gamesPlayed += 1;
          await loserUser.save();
        }
      } else if (result === "1/2-1/2") {
        // Beraberlik durumu
        const whiteUser = await User.findOne({ username: game.whitePlayer });
        const blackUser = await User.findOne({ username: game.blackPlayer });
        
        if (whiteUser) {
          whiteUser.draws += 1;
          whiteUser.gamesPlayed += 1;
          await whiteUser.save();
        }
        
        if (blackUser) {
          blackUser.draws += 1;
          blackUser.gamesPlayed += 1;
          await blackUser.save();
        }
        
        game.eloChange = { white: 0, black: 0 };
      }
    }
    
    await game.save();
    
    res.status(200).json({ 
      message: "Oyun başarıyla sonlandırıldı.",
      result,
      eloChange
    });
  } catch (err) {
    console.error("Oyun sonlandırma hatası:", err);
    res.status(500).json({ message: "Oyun sonlandırılamadı." });
  }
});

// ELO hesaplama fonksiyonu
function calculateEloChange(winnerElo, loserElo) {
  const K = 32; // K-faktörü (değişim hızı)
  const expectedScore = 1 / (1 + Math.pow(10, (loserElo - winnerElo) / 400));
  const eloChange = Math.round(K * (1 - expectedScore));
  return eloChange;
}

module.exports = router;
