const express = require("express");
const router = express.Router();
const User = require("../models/User");

// Kullanıcı istatistiklerini getir
router.get("/stats/:username", async (req, res) => {
  try {
    const username = req.params.username;
    
    // Kullanıcıyı veritabanında bul
    const user = await User.findOne({ username });
    
    if (!user) {
      return res.status(404).json({ message: "Kullanıcı bulunamadı." });
    }
    
    // Kullanıcı istatistiklerini döndür
    const stats = {
      username: user.username,
      gamesPlayed: user.gamesPlayed,
      wins: user.wins,
      losses: user.losses,
      draws: user.draws,
      elo: user.elo
    };
    
    res.status(200).json(stats);
  } catch (err) {
    console.error("Kullanıcı istatistikleri getirme hatası:", err);
    res.status(500).json({ message: "Sunucu hatası." });
  }
});

// Sıralama tablosunu getir
router.get("/leaderboard", async (req, res) => {
  try {
    // En yüksek ELO puanına sahip ilk 10 kullanıcıyı getir
    const users = await User.find({})
      .sort({ elo: -1 })
      .limit(10)
      .select('username elo wins losses draws');
    
    res.status(200).json(users);
  } catch (err) {
    console.error("Sıralama tablosu getirme hatası:", err);
    res.status(500).json({ message: "Sunucu hatası." });
  }
});

module.exports = router;
