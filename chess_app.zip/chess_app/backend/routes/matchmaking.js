const express = require("express");
const router = express.Router();
const Matchmaking = require("../models/Matchmaking");
const User = require("../models/User");

// Eşleşme isteği oluştur
router.post("/request", async (req, res) => {
  try {
    const { username, timeControl } = req.body;
    
    // Kullanıcı bilgilerini al
    const user = await User.findOne({ username });
    if (!user) return res.status(404).json({ message: "Kullanıcı bulunamadı." });
    
    // Aktif eşleşme isteği var mı kontrol et
    const existingRequest = await Matchmaking.findOne({ 
      username, 
      status: "waiting" 
    });
    
    if (existingRequest) {
      return res.status(400).json({ message: "Zaten aktif bir eşleşme isteğiniz var." });
    }
    
    // Yeni eşleşme isteği oluştur
    const matchRequest = new Matchmaking({
      userId: user._id,
      username,
      elo: user.elo,
      timeControl,
      status: "waiting"
    });
    
    await matchRequest.save();
    res.status(201).json(matchRequest);
  } catch (err) {
    res.status(500).json({ message: "Eşleşme isteği oluşturulamadı." });
  }
});

// Eşleşme isteğini iptal et
router.post("/cancel", async (req, res) => {
  try {
    const { username } = req.body;
    
    const result = await Matchmaking.findOneAndUpdate(
      { username, status: "waiting" },
      { status: "cancelled" },
      { new: true }
    );
    
    if (!result) {
      return res.status(404).json({ message: "Aktif eşleşme isteği bulunamadı." });
    }
    
    res.status(200).json({ message: "Eşleşme isteği iptal edildi." });
  } catch (err) {
    res.status(500).json({ message: "Eşleşme isteği iptal edilemedi." });
  }
});

// Aktif eşleşme isteklerini getir
router.get("/active", async (req, res) => {
  try {
    const activeRequests = await Matchmaking.find({ status: "waiting" })
      .sort({ createdAt: 1 });
    
    res.status(200).json(activeRequests);
  } catch (err) {
    res.status(500).json({ message: "Aktif eşleşme istekleri getirilemedi." });
  }
});

// Sıralama tablosunu getir
router.get("/leaderboard", async (req, res) => {
  try {
    const leaderboard = await User.find({})
      .sort({ elo: -1 })
      .limit(20)
      .select("username elo wins losses draws gamesPlayed");
    
    res.status(200).json(leaderboard);
  } catch (err) {
    res.status(500).json({ message: "Sıralama tablosu getirilemedi." });
  }
});

module.exports = router;
