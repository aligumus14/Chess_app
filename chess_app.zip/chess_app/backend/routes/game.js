const express = require("express");
const router = express.Router();
const Game = require("../models/Game");

// Yeni oyun oluştur
router.post("/create", async (req, res) => {
  try {
    const { whitePlayer, blackPlayer } = req.body;

    const newGame = new Game({
      whitePlayer,
      blackPlayer,
      moves: [],
      result: "ongoing"
    });

    const savedGame = await newGame.save();
    res.status(201).json(savedGame);
  } catch (err) {
    res.status(500).json({ message: "Oyun oluşturulamadı." });
  }
});

// Hamle ekle
router.post("/move/:gameId", async (req, res) => {
  try {
    const { move } = req.body;
    const game = await Game.findById(req.params.gameId);
    if (!game) return res.status(404).json({ message: "Oyun bulunamadı." });

    game.moves.push(move);
    await game.save();
    res.status(200).json({ message: "Hamle eklendi.", game });
  } catch (err) {
    res.status(500).json({ message: "Hamle eklenemedi." });
  }
});

// Oyun sonucu güncelle
router.post("/finish/:gameId", async (req, res) => {
  try {
    const { result } = req.body; // örnek: "1-0", "0-1", "1/2-1/2"
    const game = await Game.findById(req.params.gameId);
    if (!game) return res.status(404).json({ message: "Oyun bulunamadı." });

    game.result = result;
    await game.save();
    res.status(200).json({ message: "Oyun tamamlandı.", game });
  } catch (err) {
    res.status(500).json({ message: "Oyun sonucu güncellenemedi." });
  }
});

// Belirli bir oyuncunun tüm oyunları
router.get("/history/:username", async (req, res) => {
  try {
    const username = req.params.username;
    const games = await Game.find({
      $or: [{ whitePlayer: username }, { blackPlayer: username }]
    }).sort({ createdAt: -1 });

    res.status(200).json(games);
  } catch (err) {
    res.status(500).json({ message: "Oyun geçmişi getirilemedi." });
  }
});

module.exports = router;
