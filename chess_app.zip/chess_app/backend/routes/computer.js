const express = require("express");
const router = express.Router();
const Game = require("../models/Game");
const User = require("../models/User");

// Bilgisayara karşı yeni oyun oluştur
router.post("/", async (req, res) => {
  try {
    const { username, difficulty, timeControl, userElo } = req.body;
    
    // Kullanıcı bilgilerini al
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(404).json({ message: "Kullanıcı bulunamadı." });
    }
    
    // Zorluk seviyesine göre bilgisayar ELO'su
    const computerElo = {
      easy: 800,
      medium: 1200,
      hard: 1600,
      expert: 2000
    };
    
    // Bilgisayar adını zorluk seviyesine göre belirle
    const computerName = `Computer_${difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}`;
    
    // Yeni oyun oluştur
    const newGame = new Game({
      whitePlayer: username,
      blackPlayer: computerName,
      result: "ongoing",
      whiteElo: user.elo || 1200,
      blackElo: computerElo[difficulty] || 1200,
      timeControl: timeControl || 600,
      moves: []
    });

    const savedGame = await newGame.save();
    res.status(201).json(savedGame);
  } catch (err) {
    console.error("Bilgisayar oyunu oluşturma hatası:", err);
    res.status(500).json({ message: "Bilgisayar oyunu oluşturulamadı." });
  }
});

// Bilgisayar hamlesi yap
router.post("/move/:gameId", async (req, res) => {
  try {
    const { fen, difficulty } = req.body;
    const game = await Game.findById(req.params.gameId);
    
    if (!game) return res.status(404).json({ message: "Oyun bulunamadı." });
    
    // Chess.js kullanarak geçerli hamleleri al
    const Chess = require('chess.js').Chess;
    const chess = new Chess(fen);
    const moves = chess.moves({ verbose: true });
    
    if (moves.length === 0) {
      return res.status(200).json({ move: null });
    }
    
    let selectedMove;
    
    // Zorluk seviyesine göre hamle seçimi
    switch(difficulty) {
      case 'easy':
        // Tamamen rastgele hamle
        selectedMove = moves[Math.floor(Math.random() * moves.length)];
        break;
        
      case 'medium':
        // %70 iyi hamle, %30 rastgele hamle
        if (Math.random() < 0.3) {
          selectedMove = moves[Math.floor(Math.random() * moves.length)];
        } else {
          // Basit değerlendirme: Taş değerlerine göre en iyi hamleyi seç
          selectedMove = getBestMoveByPieceValue(chess, moves);
        }
        break;
        
      case 'hard':
        // %90 iyi hamle, %10 rastgele hamle
        if (Math.random() < 0.1) {
          selectedMove = moves[Math.floor(Math.random() * moves.length)];
        } else {
          // Daha gelişmiş değerlendirme: Taş değerleri + pozisyon
          selectedMove = getBestMoveByPieceValue(chess, moves);
        }
        break;
        
      case 'expert':
        // Her zaman en iyi hamleyi seç
        selectedMove = getBestMoveByPieceValue(chess, moves);
        break;
        
      default:
        // Varsayılan olarak orta seviye
        if (Math.random() < 0.3) {
          selectedMove = moves[Math.floor(Math.random() * moves.length)];
        } else {
          selectedMove = getBestMoveByPieceValue(chess, moves);
        }
    }
    
    // Hamleyi yap
    chess.move(selectedMove);
    
    // Hamleyi kaydet
    game.moves.push(chess.history().pop());
    await game.save();
    
    res.status(200).json({ 
      move: selectedMove,
      fen: chess.fen()
    });
  } catch (err) {
    console.error("Bilgisayar hamlesi yapma hatası:", err);
    res.status(500).json({ message: "Bilgisayar hamlesi yapılamadı." });
  }
});

// Taş değerlerine göre en iyi hamleyi seç
function getBestMoveByPieceValue(chess, moves) {
  // Taş değerleri
  const pieceValues = {
    p: 1,   // piyon
    n: 3,   // at
    b: 3,   // fil
    r: 5,   // kale
    q: 9,   // vezir
    k: 0    // şah (değer atanmaz)
  };
  
  let bestMove = null;
  let bestScore = -Infinity;
  
  for (const move of moves) {
    let score = 0;
    
    // Eğer bir taş alınıyorsa, değerini skora ekle
    if (move.captured) {
      score += pieceValues[move.captured];
    }
    
    // Eğer terfi varsa, terfi edilen taşın değerini ekle
    if (move.promotion) {
      score += pieceValues[move.promotion] - pieceValues.p;
    }
    
    // Hamleyi geçici olarak yap
    chess.move(move);
    
    // Eğer bu hamle sonrası taşımız tehdit altındaysa skoru düşür
    if (chess.in_check()) {
      score -= 2;
    }
    
    // Hamleyi geri al
    chess.undo();
    
    // En iyi skoru güncelle
    if (score > bestScore) {
      bestScore = score;
      bestMove = move;
    }
  }
  
  // En iyi hamle bulunamadıysa rastgele bir hamle seç
  return bestMove || moves[Math.floor(Math.random() * moves.length)];
}

module.exports = router;
