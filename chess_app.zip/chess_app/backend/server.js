const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");
const http = require("http");
const socketIo = require("socket.io");

const authRoutes = require("./routes/auth");
const gameRoutes = require("./routes/game");
const matchmakingRoutes = require("./routes/matchmaking");
const statsRoutes = require("./routes/stats");

const app = express();
const server = http.createServer(app);
// Doğru Socket.IO yapılandırması şöyle olmalı:
const io = require('socket.io')(server, {
  cors: {
    origin: '*', // Geliştirme için, üretimde daha kısıtlayıcı olmalı
    methods: ['GET', 'POST']
  }
});


// Middleware
app.use(cors());
app.use(express.json());

// Statik klasör (frontend)
app.use(express.static(path.join(__dirname, "../public")));

// API
app.use("/api/auth", authRoutes);
app.use("/api/games", gameRoutes);
app.use("/api/matchmaking", matchmakingRoutes);
app.use("/api/stats", statsRoutes);

// Bilgisayara karşı oyna API
const computerRoutes = require("./routes/computer");
app.use("/api/computer", computerRoutes);

// Oyun geçmişi API
const historyRoutes = require("./routes/history");
app.use("/api/history", historyRoutes);

// MongoDB bağlantısı
console.log("🔄 MongoDB bağlantısı kuruluyor...");
mongoose.connect("mongodb://localhost:27017/chess_db", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log("✅ MongoDB bağlantısı başarılı"))
.catch(err => console.error("❌ MongoDB bağlantı hatası:", err));

// Socket.IO bağlantıları için MongoDB modelleri
const User = require("./models/User");
const Game = require("./models/Game");
const Matchmaking = require("./models/Matchmaking");

// Aktif kullanıcıları takip etmek için
const activeUsers = new Map();
const activeGames = new Map();

// Chess.js kütüphanesini güvenli bir şekilde yükle
function loadChess() {
  try {
    // Önce doğrudan Chess sınıfını almayı dene
    const ChessModule = require('chess.js');
    
    // Chess.js'nin farklı versiyonlarını kontrol et
    if (typeof ChessModule === 'function') {
      console.log("[CHESS] Chess.js doğrudan constructor olarak yüklendi");
      return ChessModule;
    } else if (ChessModule.Chess && typeof ChessModule.Chess === 'function') {
      console.log("[CHESS] Chess.js modül içinde Chess property olarak yüklendi");
      return ChessModule.Chess;
    } else {
      console.error("[CHESS] Chess.js yüklenemedi: Uyumlu bir Chess constructor'ı bulunamadı");
      return null;
    }
  } catch (error) {
    console.error("[CHESS] Chess.js yükleme hatası:", error);
    return null;
  }
}

// Chess.js'yi yükle
const Chess = loadChess();

// ELO hesaplama fonksiyonu
function calculateEloChange(winnerElo, loserElo) {
  console.log(`[ELO_CALC] Kazanan ELO: ${winnerElo}, Kaybeden ELO: ${loserElo}`);
  
  // ELO değerlerinin sayı olduğundan emin ol
  winnerElo = Number(winnerElo);
  loserElo = Number(loserElo);
  
  if (isNaN(winnerElo) || isNaN(loserElo)) {
    console.error(`[ELO_ERROR] Geçersiz ELO değerleri: winnerElo=${winnerElo}, loserElo=${loserElo}`);
    return 10; // Varsayılan değer
  }
  
  const K = 32; // K-faktörü (değişim hızı)
  const expectedScore = 1 / (1 + Math.pow(10, (loserElo - winnerElo) / 400));
  const eloChange = Math.round(K * (1 - expectedScore));
  
  console.log(`[ELO_CALC] Hesaplanan ELO değişimi: ${eloChange}`);
  
  // Minimum değişim garantisi
  return Math.max(eloChange, 10);
}

io.on("connection", (socket) => {
  console.log("Yeni bağlantı:", socket.id);
  
  // Kullanıcı giriş yaptığında
  socket.on("user_connected", async (username) => {
    try {
      console.log(`[SOCKET] user_connected event alındı: ${username}, socketId: ${socket.id}`);
      
      // Kullanıcıyı aktif olarak işaretle
      activeUsers.set(username, socket.id);
      socket.username = username;
      
      // Veritabanında kullanıcıyı çevrimiçi olarak güncelle
      await User.findOneAndUpdate(
        { username },
        { isOnline: true, lastLogin: Date.now() }
      );
      
      // Aktif kullanıcıları logla
      console.log(`[ACTIVE_USERS] Güncel aktif kullanıcılar: ${Array.from(activeUsers.keys()).join(', ')}`);
      
      // Aktif kullanıcı listesini tüm bağlı kullanıcılara gönder
      io.emit("active_users", Array.from(activeUsers.keys()));
      
      console.log(`[SUCCESS] ${username} bağlandı ve aktif kullanıcılara eklendi`);
    } catch (err) {
      console.error("[ERROR] Kullanıcı bağlantı hatası:", err);
    }
  });
  
  // Kullanıcı eşleşme aradığında
  socket.on("find_match", async (data) => {
    try {
      const { username, timeControl } = data;
      console.log(`[SOCKET] find_match event alındı: ${username}, timeControl: ${timeControl}, socketId: ${socket.id}`);
      
      // Kullanıcı bilgilerini al
      const user = await User.findOne({ username });
      if (!user) {
        console.error(`[ERROR] Kullanıcı bulunamadı: ${username}`);
        socket.emit("match_error", { message: "Kullanıcı bilgileri bulunamadı." });
        return;
      }
      
      console.log(`[MATCHMAKING] ${username} eşleşme arıyor, ELO: ${user.elo}, Süre: ${timeControl}`);
      
      // Önce mevcut bekleyen eşleşme isteklerini temizle
      const deletedRequests = await Matchmaking.deleteMany({ username, status: "waiting" });
      console.log(`[DB] Silinen bekleyen eşleşme istekleri: ${deletedRequests.deletedCount}`);
      
      // Yeni eşleşme kaydı oluştur
      const matchRequest = new Matchmaking({
        userId: user._id,
        username: user.username,
        elo: user.elo,
        timeControl,
        status: "waiting"
      });
      const savedRequest = await matchRequest.save();
      console.log(`[DB] Yeni eşleşme isteği oluşturuldu: ${savedRequest._id}`);
      
      // Kullanıcıya bekleme durumunu bildir
      socket.emit("waiting_for_match");
      console.log(`[SOCKET] waiting_for_match event gönderildi: ${username}`);
      
      // Tüm bekleyen eşleşme isteklerini kontrol et
      const allWaitingRequests = await Matchmaking.find({ status: "waiting" });
      console.log(`[DB] Tüm bekleyen eşleşme istekleri: ${allWaitingRequests.length}`);
      allWaitingRequests.forEach(req => {
        console.log(`[DB] Bekleyen istek: ${req.username}, ELO: ${req.elo}, Süre: ${req.timeControl}, Oluşturulma: ${req.createdAt}`);
      });
      
      // Benzer ELO'ya sahip bekleyen eşleşmeleri bul (±200 ELO farkı)
      const potentialMatches = await Matchmaking.find({
        username: { $ne: username },
        status: "waiting",
        timeControl,
        elo: { $gte: user.elo - 200, $lte: user.elo + 200 }
      }).sort({ createdAt: 1 });
      
      console.log(`[MATCHMAKING] Potansiyel eşleşmeler: ${potentialMatches.length}`);
      potentialMatches.forEach((match, index) => {
        console.log(`[MATCHMAKING] Potansiyel eşleşme ${index+1}: ${match.username}, ELO: ${match.elo}, ID: ${match._id}`);
      });
      
      if (potentialMatches.length > 0) {
        // Eşleşme bulundu
        const match = potentialMatches[0];
        console.log(`[MATCHMAKING] Eşleşme seçildi: ${match.username}, ID: ${match._id}`);
        
        const matchUser = await User.findOne({ username: match.username });
        if (!matchUser) {
          console.error(`[ERROR] Eşleşme bulunan kullanıcı bilgileri alınamadı: ${match.username}`);
          socket.emit("match_error", { message: "Eşleşme bulunan kullanıcı bilgileri alınamadı." });
          return;
        }
        
        // Eşleşme durumlarını güncelle
        const updatedMatch = await Matchmaking.findByIdAndUpdate(
          match._id, 
          { status: "matched" }, 
          { new: true }
        );
        console.log(`[DB] Eşleşme durumu güncellendi: ${match._id}, Yeni durum: ${updatedMatch ? updatedMatch.status : 'güncelleme başarısız'}`);
        
        const updatedRequest = await Matchmaking.findByIdAndUpdate(
          matchRequest._id, 
          { status: "matched" }, 
          { new: true }
        );
        console.log(`[DB] İstek durumu güncellendi: ${matchRequest._id}, Yeni durum: ${updatedRequest ? updatedRequest.status : 'güncelleme başarısız'}`);
        
        // Yeni oyun oluştur - rastgele renk ataması
        const whitePlayer = Math.random() < 0.5 ? username : match.username;
        const blackPlayer = whitePlayer === username ? match.username : username;
        
        const whiteElo = whitePlayer === username ? user.elo : matchUser.elo;
        const blackElo = blackPlayer === username ? user.elo : matchUser.elo;
        
        console.log(`[GAME_CREATE] Beyaz: ${whitePlayer} (ELO: ${whiteElo}), Siyah: ${blackPlayer} (ELO: ${blackElo})`);
        
        const newGame = new Game({
          whitePlayer,
          blackPlayer,
          timeControl,
          whiteElo,
          blackElo,
          moves: []
        });
        
        const savedGame = await newGame.save();
        const gameRoomId = savedGame._id.toString();
        console.log(`[DB] Yeni oyun oluşturuldu: ${gameRoomId}`);
        
        // Oyun odasına katıl
        socket.join(gameRoomId);
        console.log(`[ROOM] ${username} oyun odasına katıldı: ${gameRoomId}`);
        
        // Her iki oyuncuya da eşleşme bilgisini gönder
        const opponent = match.username;
        const opponentSocketId = activeUsers.get(opponent);
        
        console.log(`[SOCKET] Rakip socket ID: ${opponentSocketId || 'bulunamadı'}`);
        console.log(`[ACTIVE_USERS] Aktif kullanıcılar: ${Array.from(activeUsers.keys()).join(', ')}`);
        
        if (opponentSocketId) {
          // Rakibi de oyun odasına ekle
          const opponentSocket = await io.fetchSockets().then(sockets => 
            sockets.find(s => s.id === opponentSocketId)
          );
          
          if (opponentSocket) {
            opponentSocket.join(gameRoomId);
            console.log(`[ROOM] ${opponent} oyun odasına katıldı: ${gameRoomId}`);
          }
          
          // Eşleşme bilgilerini gönder
          const currentPlayerData = {
            gameId: gameRoomId,
            opponent,
            color: whitePlayer === username ? "white" : "black"
          };
          
          const opponentData = {
            gameId: gameRoomId,
            opponent: username,
            color: whitePlayer === opponent ? "white" : "black"
          };
          
          console.log(`[SOCKET] match_found event gönderiliyor (mevcut oyuncu): ${JSON.stringify(currentPlayerData)}`);
          socket.emit("match_found", currentPlayerData);
          
          console.log(`[SOCKET] match_found event gönderiliyor (rakip): ${JSON.stringify(opponentData)}`);
          io.to(opponentSocketId).emit("match_found", opponentData);
          
          // Oyun takibi için
          activeGames.set(gameRoomId, {
            white: whitePlayer,
            black: blackPlayer,
            game: savedGame
          });
          
          console.log(`[SUCCESS] Eşleşme bulundu: ${username} vs ${opponent}, Oyun ID: ${gameRoomId}`);
          console.log(`[SUCCESS] Beyaz: ${whitePlayer}, Siyah: ${blackPlayer}`);
        } else {
          console.error(`[ERROR] Rakip ${opponent} çevrimiçi değil, eşleşme iptal edildi.`);
          socket.emit("match_error", { message: "Rakip çevrimiçi değil, lütfen tekrar deneyin." });
          
          // Eşleşme iptal edildi olarak işaretle
          await Matchmaking.findByIdAndUpdate(match._id, { status: "cancelled" });
          await Matchmaking.findByIdAndUpdate(matchRequest._id, { status: "cancelled" });
        }
      } else {
        console.log(`[INFO] ${username} için uygun eşleşme bulunamadı, bekleniyor...`);
      }
    } catch (err) {
      console.error("[ERROR] Eşleşme hatası:", err);
      socket.emit("match_error", { message: "Eşleşme sırasında bir hata oluştu." });
    }
  });
  
  // Oyun odasına katılma
  socket.on("join_game_room", (data) => {
    const { gameId, username } = data;
    console.log(`[ROOM] ${username} oyun odasına katılıyor: ${gameId}`);
    
    // Kullanıcı adını socket'e kaydet
    socket.username = username;
    
    // Odaya katıl
    socket.join(gameId);
    
    // Oda üyelerini logla
    io.in(gameId).fetchSockets().then(sockets => {
      console.log(`[ROOM] ${gameId} odasındaki üyeler: ${sockets.length}`);
      sockets.forEach(s => console.log(`- Socket ID: ${s.id}, Username: ${s.username || 'bilinmiyor'}`));
    });
  });
  
  // Eşleşme aramayı iptal et
  socket.on("cancel_matchmaking", async (username) => {
    try {
      await Matchmaking.deleteMany({ username, status: "waiting" });
      socket.emit("matchmaking_cancelled");
      console.log(`${username} eşleşme aramasını iptal etti`);
    } catch (err) {
      console.error("Eşleşme iptali hatası:", err);
    }
  });
  
  socket.on("make_move", async (data) => {
    let game = null;
    let currentPlayer = null;
    let opponent = null;
    let moveData = null;
    
    try {
      const { gameId, move, fen, remainingTime } = data;
      
      console.log(`[SOCKET] make_move event alındı: gameId=${gameId}, move=${JSON.stringify(move)}, socketId=${socket.id}, username=${socket.username}`);
      
      // Oyun bilgilerini al
      game = await Game.findById(gameId);
      if (!game) {
        console.error(`[ERROR] Oyun bulunamadı: ${gameId}`);
        socket.emit("game_error", { message: "Oyun bulunamadı." });
        return;
      }
      
      // Hamleyi kaydet
      game.moves.push(move);
      
      // Oyun odasına katıl (eğer katılmadıysa)
      socket.join(gameId);
      
      // Frontend'den gelen oyun sonu bilgisini kontrol et
      const frontendGameOver = data.gameOver === true;
      const frontendCheckmate = data.checkmate === true;
      
      console.log(`[GAME_STATE] Frontend'den gelen oyun sonu bilgisi: gameOver=${frontendGameOver}, checkmate=${frontendCheckmate}`);
      
      // FEN pozisyonunu kaydet ve Chess.js ile kontrol et (eğer mümkünse)
      let gameOver = false;
      let isCheckmate = false;
      let isStalemate = false;
      let isDraw = false;
      
      if (fen && Chess) {
        try {
          // Chess.js kütüphanesini doğru şekilde kullan
          const chess = new Chess();
          
          // FEN pozisyonunu yükle
          chess.load(fen);
          
          // Chess.js fonksiyonlarını kontrol et ve logla
          console.log("[CHESS] Mevcut fonksiyonlar:", 
            "game_over:", typeof chess.game_over === 'function', 
            "in_checkmate:", typeof chess.in_checkmate === 'function',
            "in_stalemate:", typeof chess.in_stalemate === 'function',
            "in_draw:", typeof chess.in_draw === 'function'
          );
          
          // Oyun bitti mi kontrol et - farklı versiyonlar için güvenli kontrol
          if (typeof chess.game_over === 'function') {
            gameOver = chess.game_over();
            console.log(`[CHESS] game_over() sonucu: ${gameOver}`);
            
            if (gameOver) {
              if (typeof chess.in_checkmate === 'function') {
                isCheckmate = chess.in_checkmate();
                console.log(`[CHESS] in_checkmate() sonucu: ${isCheckmate}`);
              }
              
              if (typeof chess.in_stalemate === 'function') {
                isStalemate = chess.in_stalemate();
                console.log(`[CHESS] in_stalemate() sonucu: ${isStalemate}`);
              }
              
              if (typeof chess.in_draw === 'function') {
                isDraw = chess.in_draw();
                console.log(`[CHESS] in_draw() sonucu: ${isDraw}`);
              }
            }
          } else {
            // Chess.js'nin eski versiyonları için alternatif kontrol
            console.log("[CHESS] game_over fonksiyonu bulunamadı, frontend'den gelen oyun sonu bilgisine güvenilecek");
          }
        } catch (error) {
          console.error("[ERROR] Chess.js oyun durumu kontrolü hatası:", error);
          // Hata durumunda sadece loglama yap, oyunun devam etmesini sağla
        }
      }
      
      currentPlayer = socket.username;
      const isWhite = currentPlayer === game.whitePlayer;
      
      // Oyun sonucunu belirle (backend veya frontend tespitine göre)
      if ((gameOver && isCheckmate) || frontendGameOver || frontendCheckmate) {
        console.log(`[GAME_OVER] Şah mat veya oyun sonu tespit edildi. Frontend: ${frontendGameOver || frontendCheckmate}, Backend: ${gameOver && isCheckmate}`);
        
        // Şah mat durumu - kazanan hamleyi yapan oyuncu
        game.result = isWhite ? "1-0" : "0-1"; // Beyaz kazandı veya siyah kazandı
        game.endTime = Date.now();
        game.reason = "checkmate";
        
        // ELO değişimini hesapla
        const winner = isWhite ? game.whitePlayer : game.blackPlayer;
        const loser = isWhite ? game.blackPlayer : game.whitePlayer;
        const winnerElo = isWhite ? game.whiteElo : game.blackElo;
        const loserElo = isWhite ? game.blackElo : game.whiteElo;
        
        console.log(`[GAME_OVER] Şah mat tespit edildi. Kazanan: ${winner}, Kaybeden: ${loser}`);
        console.log(`[GAME_OVER] ELO değerleri - Kazanan: ${winnerElo}, Kaybeden: ${loserElo}`);
        
        const eloChange = calculateEloChange(winnerElo, loserElo);
        
        // ELO değişimini kaydet
        game.eloChange = {
          white: isWhite ? eloChange : -eloChange,
          black: isWhite ? -eloChange : eloChange
        };
        
        console.log(`[GAME_OVER] ELO değişimi hesaplandı: ${eloChange}`);
        console.log(`[GAME_OVER] Oyun ELO değişimi: Beyaz: ${game.eloChange.white}, Siyah: ${game.eloChange.black}`);
        
        // Kullanıcı ELO ve istatistiklerini güncelle
        const winnerUser = await User.findOne({ username: winner });
        const loserUser = await User.findOne({ username: loser });
        
        if (winnerUser) {
          const oldElo = winnerUser.elo;
          winnerUser.elo += eloChange;
          winnerUser.wins += 1;
          winnerUser.gamesPlayed += 1;
          await winnerUser.save();
          console.log(`[ELO] ${winner} ELO güncellendi: ${oldElo} -> ${winnerUser.elo} (+${eloChange})`);
        } else {
          console.error(`[ERROR] Kazanan kullanıcı bulunamadı: ${winner}`);
        }
        
        if (loserUser) {
          const oldElo = loserUser.elo;
          loserUser.elo -= eloChange;
          loserUser.losses += 1;
          loserUser.gamesPlayed += 1;
          await loserUser.save();
          console.log(`[ELO] ${loser} ELO güncellendi: ${oldElo} -> ${loserUser.elo} (-${eloChange})`);
        } else {
          console.error(`[ERROR] Kaybeden kullanıcı bulunamadı: ${loser}`);
        }
        
        // Oyun sonucunu bildir
        socket.emit("game_over", {
          result: game.result,
          reason: "checkmate",
          eloChange: isWhite ? eloChange : -eloChange
        });
        
        // Rakibe oyun sonucunu bildir - oda üzerinden
        socket.to(gameId).emit("game_over", {
          result: game.result,
          reason: "checkmate",
          eloChange: isWhite ? -eloChange : eloChange
        });
        
        // Aktif oyunlardan kaldır
        activeGames.delete(gameId);
        
        console.log(`[GAME_OVER] Oyun bitti: ${winner} kazandı (Şah mat), ELO değişimi: ${eloChange}`);
      } 
      else if (gameOver && (isStalemate || isDraw)) {
        // Beraberlik durumu
        game.result = "1/2-1/2";
        game.endTime = Date.now();
        game.reason = isStalemate ? "stalemate" : "draw";
        
        // Beraberlikte ELO değişimi yok veya çok az
        game.eloChange = {
          white: 0,
          black: 0
        };
        
        // Kullanıcı istatistiklerini güncelle
        const whiteUser = await User.findOne({ username: game.whitePlayer });
        const blackUser = await User.findOne({ username: game.blackPlayer });
        
        if (whiteUser) {
          whiteUser.draws += 1;
          whiteUser.gamesPlayed += 1;
          await whiteUser.save();
          console.log(`[STATS] ${game.whitePlayer} istatistikleri güncellendi: beraberlik +1`);
        }
        
        if (blackUser) {
          blackUser.draws += 1;
          blackUser.gamesPlayed += 1;
          await blackUser.save();
          console.log(`[STATS] ${game.blackPlayer} istatistikleri güncellendi: beraberlik +1`);
        }
        
        // Oyun sonucunu bildir
        socket.emit("game_over", {
          result: game.result,
          reason: game.reason,
          eloChange: 0
        });
        
        // Rakibe oyun sonucunu bildir - oda üzerinden
        socket.to(gameId).emit("game_over", {
          result: game.result,
          reason: game.reason,
          eloChange: 0
        });
        
        // Aktif oyunlardan kaldır
        activeGames.delete(gameId);
        
        console.log(`[GAME_OVER] Oyun bitti: Beraberlik (${game.reason})`);
      }
      
      // Oyunu kaydet
      await game.save();
      console.log(`[DB] Oyun kaydedildi: ${gameId}, Hamle sayısı: ${game.moves.length}`);
      
      // Rakibe hamleyi bildir - oda üzerinden
      currentPlayer = socket.username;
      opponent = currentPlayer === game.whitePlayer ? game.blackPlayer : game.whitePlayer;
      
      console.log(`[MOVE] Hamle yapıldı: ${currentPlayer} -> ${JSON.stringify(move)}, Rakip: ${opponent}, Oda: ${gameId}`);
      
      // Hamle verisini hazırla
      moveData = {
        gameId,
        move,
        fen,
        remainingTime
      };
      
      console.log(`[EMIT] opponent_move eventi gönderiliyor: ${JSON.stringify(moveData)}`);
      
      // Odadaki diğer oyunculara hamleyi gönder
      socket.to(gameId).emit("opponent_move", moveData);
      
      console.log(`[SUCCESS] Hamle odaya iletildi: ${gameId}`);
      
      // Aktif oyun bilgisini güncelle
      if (activeGames.has(gameId)) {
        const activeGame = activeGames.get(gameId);
        activeGame.game = game;
        activeGames.set(gameId, activeGame);
      }
    } catch (err) {
      console.error("[ERROR] Hamle hatası:", err);
      socket.emit("game_error", { message: "Hamle yapılırken bir hata oluştu." });
      
      // Hata durumunda da oyun kaydı ve ELO işlemlerini gerçekleştir
      if (game) {
        try {
          // Oyunu kaydet
          await game.save();
          console.log(`[DB] (Hata sonrası) Oyun kaydedildi: ${game._id}`);
          
          // Eğer moveData ve currentPlayer tanımlanmışsa, rakibe hamleyi bildir
          if (moveData && currentPlayer && opponent) {
            console.log(`[MOVE] (Hata sonrası) Hamle yapıldı: ${currentPlayer} -> ${JSON.stringify(moveData.move)}, Rakip: ${opponent}, Oda: ${moveData.gameId}`);
            
            // Odadaki diğer oyunculara hamleyi gönder
            socket.to(moveData.gameId).emit("opponent_move", moveData);
            
            console.log(`[SUCCESS] (Hata sonrası) Hamle odaya iletildi: ${moveData.gameId}`);
            
            // Aktif oyun bilgisini güncelle
            if (activeGames.has(moveData.gameId)) {
              const activeGame = activeGames.get(moveData.gameId);
              activeGame.game = game;
              activeGames.set(moveData.gameId, activeGame);
            }
          }
        } catch (saveErr) {
          console.error("[ERROR] Hata sonrası oyun kaydetme hatası:", saveErr);
        }
      }
    }
  });

  
  // Oyun sonucu bildirildiğinde
  socket.on("game_over", async (data) => {
    try {
      const { gameId, result, reason } = data;
      
      console.log(`[SOCKET] game_over event alındı: gameId=${gameId}, result=${result}, reason=${reason}`);
      
      // Oyun bilgilerini al
      const game = await Game.findById(gameId);
      if (!game) {
        console.error(`[ERROR] Oyun bulunamadı: ${gameId}`);
        return;
      }
      
      // Oyun zaten sonuçlandıysa işlem yapma
      if (game.result !== "ongoing") {
        console.log(`[INFO] Oyun zaten sonuçlanmış: ${gameId}, Sonuç: ${game.result}`);
        return;
      }
      
      // Oyun sonucunu kaydet
      game.result = result;
      game.endTime = Date.now();
      game.reason = reason;
      
      // Teslim olma veya zaman aşımı durumlarında ELO hesapla
      if (reason === "resignation" || reason === "timeout" || reason === "checkmate") {
        const currentPlayer = socket.username;
        
        // Kazanan ve kaybedeni belirle
        let winner, loser;
        if (reason === "resignation") {
          // Teslim olan kaybeder
          winner = currentPlayer === game.whitePlayer ? game.blackPlayer : game.whitePlayer;
          loser = currentPlayer;
        } else if (reason === "timeout") {
          // Zamanı biten kaybeder
          loser = currentPlayer;
          winner = currentPlayer === game.whitePlayer ? game.blackPlayer : game.whitePlayer;
        } else if (reason === "checkmate") {
          // Şah mat durumunda, sonucu belirle
          if (result === "1-0") {
            winner = game.whitePlayer;
            loser = game.blackPlayer;
          } else {
            winner = game.blackPlayer;
            loser = game.whitePlayer;
          }
        }
        
        // ELO değişimini hesapla
        const winnerIsWhite = winner === game.whitePlayer;
        const winnerElo = winnerIsWhite ? game.whiteElo : game.blackElo;
        const loserElo = winnerIsWhite ? game.blackElo : game.whiteElo;
        
        console.log(`[GAME_OVER] ${reason} nedeniyle oyun bitti. Kazanan: ${winner}, Kaybeden: ${loser}`);
        console.log(`[GAME_OVER] ELO değerleri - Kazanan: ${winnerElo}, Kaybeden: ${loserElo}`);
        
        const eloChange = calculateEloChange(winnerElo, loserElo);
        
        // ELO değişimini kaydet
        game.eloChange = {
          white: winnerIsWhite ? eloChange : -eloChange,
          black: winnerIsWhite ? -eloChange : eloChange
        };
        
        console.log(`[GAME_OVER] ELO değişimi hesaplandı: ${eloChange}`);
        console.log(`[GAME_OVER] Oyun ELO değişimi: Beyaz: ${game.eloChange.white}, Siyah: ${game.eloChange.black}`);
        
        // Kullanıcı ELO ve istatistiklerini güncelle
        const winnerUser = await User.findOne({ username: winner });
        const loserUser = await User.findOne({ username: loser });
        
        if (winnerUser) {
          const oldElo = winnerUser.elo;
          winnerUser.elo += eloChange;
          winnerUser.wins += 1;
          winnerUser.gamesPlayed += 1;
          await winnerUser.save();
          console.log(`[ELO] ${winner} ELO güncellendi: ${oldElo} -> ${winnerUser.elo} (+${eloChange})`);
        } else {
          console.error(`[ERROR] Kazanan kullanıcı bulunamadı: ${winner}`);
        }
        
        if (loserUser) {
          const oldElo = loserUser.elo;
          loserUser.elo -= eloChange;
          loserUser.losses += 1;
          loserUser.gamesPlayed += 1;
          await loserUser.save();
          console.log(`[ELO] ${loser} ELO güncellendi: ${oldElo} -> ${loserUser.elo} (-${eloChange})`);
        } else {
          console.error(`[ERROR] Kaybeden kullanıcı bulunamadı: ${loser}`);
        }
        
        // Oyun sonucunu güncelle
        game.result = winnerIsWhite ? "1-0" : "0-1";
        
        console.log(`[GAME_OVER] Oyun bitti: ${winner} kazandı (${reason}), ELO değişimi: ${eloChange}`);
      }
      
      // Oyunu kaydet
      await game.save();
      console.log(`[DB] Oyun sonucu kaydedildi: ${gameId}, Sonuç: ${game.result}, Neden: ${game.reason}`);
      
      // Aktif oyunlardan kaldır
      activeGames.delete(gameId);
      console.log(`[ACTIVE_GAMES] Oyun aktif listeden kaldırıldı: ${gameId}`);
    } catch (err) {
      console.error("[ERROR] Oyun sonucu işleme hatası:", err);
    }
  });
  
  // Bağlantı kesildiğinde
  socket.on("disconnect", async () => {
    try {
      const username = socket.username;
      if (username) {
        console.log(`[SOCKET] disconnect event alındı: ${username}, socketId: ${socket.id}`);
        
        // Kullanıcıyı aktif listesinden çıkar
        activeUsers.delete(username);
        
        // Aktif kullanıcıları logla
        console.log(`[ACTIVE_USERS] Güncel aktif kullanıcılar (çıkış sonrası): ${Array.from(activeUsers.keys()).join(', ')}`);
        
        // Aktif kullanıcı listesini güncelle
        io.emit("active_users", Array.from(activeUsers.keys()));
        
        console.log(`[SUCCESS] ${username} bağlantısı kesildi ve aktif kullanıcılardan çıkarıldı`);
        
        // Bekleyen eşleşme isteklerini iptal et
        const cancelledRequests = await Matchmaking.updateMany(
          { username, status: "waiting" },
          { status: "cancelled" }
        );
        
        if (cancelledRequests.modifiedCount > 0) {
          console.log(`[DB] ${username} için ${cancelledRequests.modifiedCount} bekleyen eşleşme isteği iptal edildi`);
        }
      }
    } catch (err) {
      console.error("[ERROR] Bağlantı kesme hatası:", err);
    }
  });
});

// Server başlat
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`🚀 Server ${PORT} portunda çalışıyor`));
