const mongoose = require("mongoose");

const matchmakingSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  },
  username: {
    type: String,
    required: true
  },
  elo: {
    type: Number,
    required: true
  },
  timeControl: {
    type: Number,
    required: true,
    default: 600 // 10 dakika (saniye cinsinden)
  },
  status: {
    type: String,
    enum: ["waiting", "matched", "cancelled"],
    default: "waiting"
  },
  createdAt: {
    type: Date,
    default: Date.now,
    expires: 600 // 10 dakika sonra otomatik silinir (5 dakikadan 10 dakikaya çıkarıldı)
  }
});

module.exports = mongoose.model("Matchmaking", matchmakingSchema);
