const mongoose = require("mongoose");

const gameSchema = new mongoose.Schema({
  whitePlayer: {
    type: String,
    required: true
  },
  blackPlayer: {
    type: String,
    required: true
  },
  moves: [{
    type: mongoose.Schema.Types.Mixed
  }],
  result: {
    type: String,
    enum: ["ongoing", "1-0", "0-1", "1/2-1/2"],
    default: "ongoing"
  },
  reason: {
    type: String,
    enum: ["normal", "timeout", "resignation", "draw", "abandoned", "checkmate", "stalemate"],
    default: "normal"
  },
  startTime: {
    type: Date,
    default: Date.now
  },
  endTime: {
    type: Date
  },
  timeControl: {
    type: Number,
    default: 600 // 10 dakika (saniye cinsinden)
  },
  whiteElo: {
    type: Number
  },
  blackElo: {
    type: Number
  },
  eloChange: {
    white: { type: Number },
    black: { type: Number }
  }
}, { timestamps: true });

module.exports = mongoose.model("Game", gameSchema);
